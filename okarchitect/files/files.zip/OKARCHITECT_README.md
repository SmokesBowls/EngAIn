# OKArchitect - Specialized AI Council for EngAIn Development

## 🏗️ What Is OKArchitect?

**OKArchitect** is a specialized AI council built on the proven **OKGPT architecture** but optimized specifically for game engine development, ZW protocol, AP rules, and EngAIn workflows.

Instead of general-purpose personas (Bob, Rod, Sarah), OKArchitect uses **5 specialized models** chosen for their strengths in systems programming, mathematical logic, and formal code generation.

## 🎯 Council Members

| Member | Model | Specialty | Purpose |
|--------|-------|-----------|---------|
| **Reasoner** | `dolphin-llama3:latest` | Strategic Architecture | Big-picture thinking, architectural decisions, design patterns |
| **Validator** | `phi3:mini-128k` | Fast Validation | Catches errors, sanity checks, prevents runaway logic |
| **EngineerA** | `deepseek-coder:6.7b` | Systems Engineering | Main implementation backbone, Python, broad correctness |
| **EngineerB** | `qwen2.5-coder:7b` | Formal Code Patterns | Strict, clean, low-error patterns, structured correctness |
| **StructuralLogic** | `joreilly86/structural_llama_3.0` | Mathematical Logic | AP rules, ZON transforms, ZW parsing, optimization |

## 📦 Installation

### 1. Pull Required Models

```bash
# Reasoning brain
ollama pull dolphin-llama3:latest

# Fast validator / timeout handler
ollama pull phi3:mini-128k

# Three specialized coders
ollama pull deepseek-coder:6.7b
ollama pull qwen2.5-coder:7b
ollama pull joreilly86/structural_llama_3.0
```

### 2. Make Executable

```bash
chmod +x okarchitect.py
```

## 🚀 Usage

### Interactive Mode

```bash
./okarchitect.py
```

Then use commands:
- `consult [question]` - Ask the full council
- `debate [question]` - Multi-round debate mode
- `ask [member] [question]` - Ask specific member
- `synthesize` - Get final decision from last consultation
- `history` - Show conversation history

### Quick Consultation

```bash
./okarchitect.py --quick "Should I use ECS architecture or inheritance for my game entities?"
```

### Debate Mode

```bash
./okarchitect.py --debate "What's the best way to implement AP rule validation?" --rounds 3
```

## 🎮 Perfect For

- **EngAIn architecture** decisions
- **ZW protocol** design questions
- **AP rules** implementation
- **ZON transforms** and 4D memory
- **Cathedral Counter** transmutation logic
- **Godot integration** strategies
- **TMC (Thematic Coding)** patterns
- **MrLore** query optimization
- **Performance optimization**
- **Algorithm design**

## 🔄 How It Differs from OKGPT

| Feature | OKGPT | OKArchitect |
|---------|-------|-------------|
| **Purpose** | General multi-agent consultation | Game engine development |
| **Members** | Bob, Rod, Sarah, Quick (general roles) | 5 specialized technical models |
| **Focus** | Broad problem solving | Systems programming, math, formal patterns |
| **Best For** | General questions, creative work | Technical architecture, code generation |
| **Backup Model** | Various | phi3:latest (fast validation) |

## 💡 Example Consultations

### Architecture Decision
```
consult Should I use pure functional kernels or stateful services for my game subsystems?
```

The council will discuss:
- **Reasoner**: High-level architectural tradeoffs
- **Validator**: Quick sanity check on approach
- **EngineerA**: Practical implementation concerns
- **EngineerB**: Formal pattern implications
- **StructuralLogic**: Mathematical/performance analysis

### AP Rule Implementation
```
ask StructuralLogic How should I validate AP rule constraints mathematically?
```

### Code Review
```
debate Is my ZW parser efficient enough or should I optimize it?
```

## 🔧 Configuration

Edit the `OKArchitect.__init__()` method to:
- Change model names
- Adjust timeouts (default: 90s)
- Modify personalities
- Change backup model
- Adjust Ollama API URL

## 📊 Sequential vs Parallel Mode

**Sequential** (default, recommended):
- Each member sees previous responses
- Builds on others' insights
- More coherent final decision
- Takes longer

**Parallel**:
- All members respond independently
- Faster
- More diverse perspectives
- Less synthesis

Use sequential for complex decisions, parallel for quick checks.

## 🎯 Best Practices

1. **Start with Reasoner** for big-picture questions
2. **Use Validator** for quick sanity checks
3. **Consult EngineerA** for practical implementation
4. **Ask EngineerB** when you need clean, formal patterns
5. **Defer to StructuralLogic** for math, algorithms, optimization

6. **Use debate mode** for controversial architectural decisions
7. **Synthesize** after consultations to get unified recommendations

## 🏛️ OKGPT vs OKArchitect - When to Use

**Use OKGPT when:**
- General problem solving
- Creative brainstorming
- Broad perspectives needed
- Non-technical decisions

**Use OKArchitect when:**
- Game engine architecture
- Code generation and review
- Mathematical/algorithmic problems
- ZW/AP/EngAIn specific work
- Performance optimization
- Formal pattern design

## 🔮 Future Enhancements

- [ ] Web UI for visual consultation
- [ ] Export conversations to markdown
- [ ] Integration with MrLore for lore-aware coding
- [ ] Direct code execution via TRAE
- [ ] Save/load council sessions
- [ ] Custom model profiles
- [ ] Parallel consultation mode
- [ ] Voice interface

## 📝 Notes

- Built on OKGPT's proven architecture
- Optimized for RTX 2070 8GB VRAM
- Models run sequentially (not simultaneously)
- ~4-8GB RAM per model when active
- Each consultation can take 2-10 minutes depending on complexity
- Backup model activates on timeout/error

## 🎓 Philosophy

OKArchitect embodies the principle that **complex systems need specialized expertise**. Rather than asking one generalist AI, you're consulting a **technical council** where each member brings specific domain knowledge to the table.

This mirrors how real software architecture works - you don't ask the same person about UI design, database optimization, and mathematical algorithms. You consult specialists.

---

**Built on the OKGPT blueprint**
**Specialized for EngAIn development**
**Optimized for deep technical consultations**
