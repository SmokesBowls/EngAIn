#!/usr/bin/env python3
import re
import sys
from dataclasses import dataclass
from typing import List, Optional

##############################################
#  CHARACTER LIST (extend as needed)
##############################################
KNOWN_NAMES = {
    "Senareth", "Vairis", "Elyraen", "Olythae",
    "Torhh", "Kyreth", "Heminra", "Malthish"
}

##############################################
#  REGEX
##############################################
TYPE_RE = re.compile(
    r'^\{type:([a-z_]+)(?:,\s*speaker:([A-Za-z_]+))?\}'
)

# Updated thought regex (fixes single-char t)
ASTERISK_THOUGHT_RE = re.compile(
    r'\*([A-Za-z][A-Za-z0-9 ,."\'?;:!\-]{2,})\*'
)

##############################################
#  SEGMENT CLASS
##############################################
@dataclass
class Segment:
    tag_line_no: int
    text_line_no: int
    type: str
    speaker: Optional[str]
    text: str

##############################################
#  LOAD SEGMENTS (supports 1-line segments)
##############################################
def load_segments(path: str) -> List[Segment]:
    segments = []
    with open(path, "r", encoding="utf-8") as f:
        lines = [line.rstrip("\n") for line in f]

    for idx, line in enumerate(lines, start=1):
        m = TYPE_RE.match(line.strip())
        if not m:
            continue

        seg_type = m.group(1).strip()
        seg_speaker = m.group(2).strip() if m.group(2) else None

        # Extract text after closing brace
        after = ""
        if "}" in line:
            after = line.split("}", 1)[-1].strip()

        segments.append(
            Segment(
                tag_line_no=idx,
                text_line_no=idx,
                type=seg_type,
                speaker=seg_speaker,
                text=after
            )
        )
    return segments

##############################################
#  SPEAKER INFERENCE
##############################################
def infer_speakers(segments: List[Segment]):
    atoms = []
    for seg in segments:
        if seg.type != "dialogue":
            continue

        if seg.speaker and seg.speaker in KNOWN_NAMES:
            atoms.append((seg.text_line_no, seg.speaker, 0.95))
            continue

        m = re.search(r'\b([A-Z][a-zA-Z]+)\s+(?:said|replied|countered|observed|murmured|whispered)', seg.text)
        if m:
            name = m.group(1)
            if name in KNOWN_NAMES:
                atoms.append((seg.text_line_no, name, 0.95))

    return atoms

##############################################
#  PRONOUN → ACTOR (SAFELY)
##############################################
PRONOUNS = {"he", "she", "they", "them", "his", "her"}

def infer_pronouns(segments: List[Segment]):
    atoms = []
    last_actor = None

    for seg in segments:
        words = seg.text.split()
        if not words:
            continue

        for w in words:
            lw = w.lower().strip(",.;!?")
            if lw in PRONOUNS and last_actor in KNOWN_NAMES:
                atoms.append((seg.text_line_no, last_actor, 0.80))
                break

        # update last_actor ONLY if it's a known character
        if words:
            token = words[0].strip(",.;!?")
            if token in KNOWN_NAMES:
                last_actor = token

    return atoms

##############################################
#  EMOTION EXTRACTION
##############################################
def infer_emotions(segments):
    atoms = []

    EMOTION_KEYWORDS = {
        "fear": "fear",
        "anger": "anger",
        "hope": "hope",
        "gratitude": "gratitude",
        "wonder": "wonder",
        "triumph": "triumph",
        "relief": "relief"
    }

    KNOWN_NAMES = {
        "Senareth", "Elyraen", "Kyreth", "Vairis", "Torhh", "Olythae"
    }

    for seg in segments:
        text = seg.text
        lower = text.lower()

        # PASS 1: SIMPLE EMOTION MATCH
        for emo_word in EMOTION_KEYWORDS:
            if emo_word in lower:
                subject = None

                idx = segments.index(seg)
                for prev in reversed(segments[:idx+1]):
                    for w in prev.text.split():
                        w_clean = w.strip(",.;!?")
                        if w_clean in KNOWN_NAMES:
                            subject = w_clean
                            break
                    if subject:
                        break

                if subject:
                    atoms.append((seg.text_line_no, subject, EMOTION_KEYWORDS[emo_word], 0.9))

        # PASS 2: MULTI-EMOTION LINES: "Wonder. Triumph. Relief. Hope."
        parts = [
            p.strip() for p in text.replace("!", ".").replace("?", ".").split(".")
            if p.strip()
        ]

        for token in parts:
            t_low = token.lower()
            if t_low in EMOTION_KEYWORDS:
                subject = None

                idx = segments.index(seg)
                for prev in reversed(segments[:idx+1]):
                    for w in prev.text.split():
                        w_clean = w.strip(",.;!?")
                        if w_clean in KNOWN_NAMES:
                            subject = w_clean
                            break
                    if subject:
                        break

                if subject:
                    atoms.append((seg.text_line_no, subject, EMOTION_KEYWORDS[t_low], 1.0))

    return atoms


##############################################
#  ACTION DETECTION
##############################################
ACTION_KEYWORDS = {
    "retreat": "retreat",
    "retreated": "retreat",
    "withdraw": "retreat",
    "submission": "submission",
    "kneeled": "submission",
    "kneeling": "submission",

    "attack": "attack",
    "struck": "attack",

    "vrill": "vrill_energy",
    "vrill-manipulation": "vrill_manipulation",
    "manipulated": "vrill_manipulation",

    "shaping": "shaping",
    "shape": "shaping",

    "create": "creation",
    "created": "creation",

    "chemical": "chemical_fear",
}

def infer_actions(segments):
    atoms = []  
    seen = set()

    for seg in segments:
        if seg.type != "narration":
            continue

        line_no = seg.text_line_no
        text = seg.text.lower()

        for keyword, normalized in ACTION_KEYWORDS.items():
            if keyword in text:
                key = (line_no, normalized)
                if key not in seen:
                    seen.add(key)
                    # RETURN TUPLE (line_no, normalized, conf)
                    atoms.append((line_no, normalized, 0.90))

    return atoms


##############################################
#  THOUGHT DETECTION
##############################################
def infer_thoughts(segments: List[Segment]):
    atoms = []

    for seg in segments:
        # explicit "X thought"
        m = re.search(r'([A-Z][a-zA-Z]+)\s+thought', seg.text)
        if m:
            name = m.group(1)
            if name in KNOWN_NAMES:
                atoms.append((seg.text_line_no, name, 1.00))

        # *italic* thoughts
        for m in ASTERISK_THOUGHT_RE.finditer(seg.text):
            atoms.append((seg.text_line_no, "unknown", 0.60))

    return atoms

##############################################
#  WRITE METTA
##############################################
def write_metta(path: str,
                speakers, pronouns, emotions, actions, thoughts):

    with open(path, "w", encoding="utf-8") as f:
        f.write("; PASS2 CORE++ INFERENCES\n\n")

        f.write("; ---- Speaker Inference ----\n")
        for line, who, conf in speakers:
            f.write(f"(speaker line:{line} {who} :confidence {conf})\n")
        f.write("\n")

        f.write("; ---- Pronoun → Actor ----\n")
        for line, who, conf in pronouns:
            f.write(f"(actor line:{line} {who} :confidence {conf})\n")
        f.write("\n")

        f.write("; ---- Emotions ----\n")
        for line, who, emotion, conf in emotions:
            f.write(f"(emotion line:{line} {who} {emotion} :confidence {conf})\n")
        f.write("\n")

        f.write("; ---- Actions ----\n")
        for line, act, conf in actions:
            f.write(f"(action line:{line} {act} :confidence {conf})\n")
        f.write("\n")

        f.write("; ---- Thoughts ----\n")
        for line, who, conf in thoughts:
            f.write(f"(thought line:{line} {who} :confidence {conf})\n")
        f.write("\n")

##############################################
#  MAIN
##############################################
def main():
    if len(sys.argv) < 2:
        print("Usage: python3 pass2_core.py <out_pass1_file>")
        return

    src = sys.argv[1]
    base = src.rsplit("/", 1)[-1]
    out = f"out_pass2_{base}.metta"

    segments = load_segments(src)

    speakers = infer_speakers(segments)
    pronouns = infer_pronouns(segments)
    emotions = infer_emotions(segments)
    actions = infer_actions(segments)
    thoughts = infer_thoughts(segments)

    write_metta(out, speakers, pronouns, emotions, actions, thoughts)

    print(f"[PASS-2 CORE++] Inference complete → {out}")

if __name__ == "__main__":
    main()
