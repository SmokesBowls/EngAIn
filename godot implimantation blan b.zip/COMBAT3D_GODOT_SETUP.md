# COMBAT3D_GODOT_SETUP.md
# Combat3D Integration - Godot Setup Guide

## Files to Add to Your Godot Project

1. **combat3d.gd** → `res://scripts/combat3d.gd`
   - Core combat system (singleton)

2. **combat_component.gd** → `res://scripts/combat_component.gd`
   - Component to attach to entities

## Setup Steps

### 1. Create Directory Structure
In your Godot project:
```
res://
├── scripts/
│   ├── combat3d.gd          (core system)
│   └── combat_component.gd  (entity component)
```

### 2. Configure Combat3D as Autoload (Singleton)

**In Godot Editor:**
1. Go to **Project → Project Settings → Autoload**
2. Click **Add**
3. Path: `res://scripts/combat3d.gd`
4. Node Name: `Combat3D`
5. Click **Add**

This makes Combat3D globally accessible from any script.

### 3. Create Test Scene

**Scene Structure:**
```
Node3D (root)
├── DirectionalLight3D
├── Camera3D
├── Ground (MeshInstance3D with plane)
├── Guard (CharacterBody3D)
│   ├── MeshInstance3D (capsule)
│   ├── CollisionShape3D
│   └── CombatComponent (script: combat_component.gd)
│       - entity_id: "guard"
│       - max_health: 100
│       - show_health_bar: true
└── Enemy (CharacterBody3D)
    ├── MeshInstance3D (cube)
    ├── CollisionShape3D
    └── CombatComponent (script: combat_component.gd)
        - entity_id: "enemy"
        - max_health: 50
        - show_health_bar: true
```

### 4. Test Script (Attach to Root Node)

Create `test_combat.gd`:
```gdscript
extends Node3D

@onready var Combat3D = get_node("/root/Combat3D")

func _ready():
	print("=== Combat3D Test Scene ===")
	print("Press SPACE to damage guard")
	print("Press ENTER to damage enemy")

func _process(_delta):
	# Process combat system each frame
	Combat3D.process_tick()

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_SPACE:
			# Enemy damages guard
			print("\n[TEST] Enemy attacks guard!")
			Combat3D.apply_damage("enemy", "guard", 25.0)
		
		elif event.keycode == KEY_ENTER:
			# Guard damages enemy
			print("\n[TEST] Guard attacks enemy!")
			Combat3D.apply_damage("guard", "enemy", 15.0)
```

### 5. Run and Test

**Expected Behavior:**
1. Scene opens with Guard and Enemy, both showing health bars
2. Press **SPACE** → Guard takes 25 damage, health bar updates
3. Keep pressing → Guard reaches low health (25%), console shows alert
4. Keep pressing → Guard dies (0 HP), fades out, collision disabled
5. Press **ENTER** → Enemy takes damage similarly

**Console Output Should Show:**
```
[Combat3D] System initialized
[Combat3D] Registered: guard with 100/100 HP
[Combat3D] Registered: enemy with 50/50 HP
[CombatComponent] guard ready with 100 HP
[CombatComponent] enemy ready with 50 HP

[TEST] Enemy attacks guard!
[guard] Took 25 damage from enemy
[guard] Took 25 damage from enemy
[guard] Took 25 damage from enemy
[Combat3D] guard is low health (25/100)
[guard] LOW HEALTH!
[guard] Took 25 damage from enemy
[Combat3D] guard died
[guard] DIED
```

## Integration with Python Backend

To connect this to your Python Combat3D system:

### Option 1: HTTP Bridge
```gdscript
# In combat3d.gd, add sync function:
func sync_with_python(python_url: String):
	var http = HTTPRequest.new()
	add_child(http)
	
	# Send current state
	var state = {
		"entities": []
	}
	for id in entities:
		var e = entities[id]
		state["entities"].append({
			"id": id,
			"health": e.health,
			"max_health": e.max_health,
			"alive": e.alive
		})
	
	http.request(python_url + "/combat/sync", [], HTTPClient.METHOD_POST, JSON.stringify(state))
```

### Option 2: Direct Python Integration (GDExtension)
For tighter integration, you can call Python directly using GDExtension or godot-python.

### Option 3: Shared State File
```gdscript
# Write combat state to file
func save_state_to_file(path: String):
	var file = FileAccess.open(path, FileAccess.WRITE)
	var state = {}
	for id in entities:
		var e = entities[id]
		state[id] = {
			"health": e.health,
			"max_health": e.max_health,
			"alive": e.alive
		}
	file.store_string(JSON.stringify(state))
	file.close()

# Python can read this file and sync
```

## API Reference

### Combat3D (Singleton)

**register_entity(entity_id: String, health: float, max_health: float)**
Register entity with combat system.

**apply_damage(source_id: String, target_id: String, amount: float)**
Queue damage to be processed next tick.

**process_tick()**
Process all queued damage. Call this each frame.

**get_health(entity_id: String) -> float**
Get current health.

**is_alive(entity_id: String) -> bool**
Check if entity is alive.

### Signals

**entity_damaged(entity_id: String, damage: float, source_id: String)**
Emitted when entity takes damage.

**entity_died(entity_id: String)**
Emitted when entity health reaches 0.

**entity_low_health(entity_id: String)**
Emitted when entity health drops below 25%.

### CombatComponent

Attach this to any Node3D to give it combat capabilities.

**Properties:**
- `entity_id: String` - Unique identifier
- `max_health: float` - Maximum health
- `show_health_bar: bool` - Display health bar above entity
- `health_bar_offset: Vector3` - Health bar position offset

**Methods:**
- `take_damage(amount: float, source_id: String)` - Public API to damage this entity

## Troubleshooting

**Health bars don't appear:**
- Check that `show_health_bar` is enabled
- Verify Camera3D is positioned to see entities
- Check console for Combat3D initialization messages

**Damage not applying:**
- Make sure `Combat3D.process_tick()` is called each frame
- Verify entity IDs match between apply_damage calls and registered entities
- Check console output for combat events

**Signals not firing:**
- Ensure signals are connected in _ready()
- Verify combat system is processing (process_tick called)

## Next Steps

Once basic combat is working visually:
1. Add hit detection (Area3D overlap → apply_damage)
2. Add AI behavior (flee on low health)
3. Add attack animations
4. Add damage effects (particles, screen shake)
5. Connect to Python sim for complex AI

---

**Status:** Ready to test in Godot!
