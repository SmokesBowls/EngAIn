# EngAIn Pipeline Dashboard - Artistic Edition

🎨 **Your concept art, integrated into the pipeline interface!**

## Available Versions

### 1. **pipeline_dashboard.jsx** (Original)
Clean, modern interface with gradient backgrounds
- Purple/slate gradient
- Cyan accents
- No artwork integration

### 2. **pipeline_dashboard_artistic.jsx** (🌟 NEW!)
Your gorgeous pixel art integrated with dynamic backgrounds!
- Different artwork per tab
- Embossed/watermark effects
- Preserves full readability
- Cosmic particle effects
- Enhanced glow and blur effects

## Concept Art Integration

The artistic version uses your game concept art strategically:

| Tab | Artwork | Theme |
|-----|---------|-------|
| **Overview** | The Akashic Records | Cosmic library = ZON memory fabric |
| **Pipeline** | The Unmade | Epic transformation = data pipeline |
| **Architecture** | Father's Embrace | Tech + magic = system design |
| **Troubleshoot** | Mother and Son | Problem solving = debugging |

## Visual Effects

### Background Treatment
- **Opacity**: 15% (subtle, not overwhelming)
- **Blur**: 3px (soft focus)
- **Saturation**: 130% (enhanced colors)
- **Scale**: 110% (slight zoom for depth)

### Overlay Layers
1. **Primary gradient**: slate-900/95 → purple-900/90
2. **Vertical gradient**: Creates depth
3. **Particle effects**: Animated cyan/purple dots
4. **Glass morphism**: Frosted glass cards

### Color Extraction
The dashboard uses colors from your art:
- **Cyan accents** (#64b5f6) - from holographic displays
- **Purple tones** (#bb86fc) - from energy effects
- **Deep blues** - from cosmic backgrounds
- **Fire oranges** - subtle highlights

## How to Use

### Option A: Direct Integration
If using in a React project, the artwork paths are already configured:
```jsx
const tabArtwork = {
  overview: 'photo_2025-10-18_01-09-19.jpg',    // Akashic Records
  pipeline: 'photo_2025-11-04_05-38-07.jpg',    // The Unmade
  architecture: 'photo_2025-11-04_05-37-56.jpg', // Father's Embrace
  troubleshoot: 'photo_2025-11-04_05-37-58.jpg'  // Mother and Son
};
```

### Option B: Custom Paths
Update the image paths in the component:
```jsx
// Change from /mnt/user-data/uploads/
// To your public assets folder
backgroundImage: `url(/assets/artwork/${tabArtwork[activeTab]})`
```

### Option C: Base64 Embed
For standalone HTML artifact, images can be embedded as base64.

## Customization Options

### Adjust Background Opacity
```jsx
// Current: 15% opacity
style={{ opacity: 0.15 }}

// More subtle: 10%
style={{ opacity: 0.10 }}

// More prominent: 25%
style={{ opacity: 0.25 }}
```

### Change Blur Amount
```jsx
// Current: 3px blur
filter: 'blur(3px) saturate(1.3)'

// Sharper: 1px
filter: 'blur(1px) saturate(1.3)'

// Softer: 5px
filter: 'blur(5px) saturate(1.3)'
```

### Disable Per-Tab Switching
```jsx
// Use single artwork for all tabs
const tabArtwork = {
  overview: 'akashic_records.jpg',
  pipeline: 'akashic_records.jpg',    // Same for all
  architecture: 'akashic_records.jpg',
  troubleshoot: 'akashic_records.jpg'
};
```

## Visual Hierarchy

The design maintains readability through layering:

```
┌─────────────────────────────────────┐
│ Content Layer (z-index: 10)         │ ← You read this
├─────────────────────────────────────┤
│ Gradient Overlays (opacity: 90-95%) │ ← Ensures readability
├─────────────────────────────────────┤
│ Particle Effects (opacity: 30%)     │ ← Subtle animation
├─────────────────────────────────────┤
│ Artwork Layer (opacity: 15%)        │ ← Your concept art
└─────────────────────────────────────┘
```

## File Manifest

### Dashboard Files
- `pipeline_dashboard.jsx` - Original clean version
- `pipeline_dashboard_artistic.jsx` - Art-integrated version
- `quick_reference.html` - HTML reference guide

### Concept Art
- `photo_2025-10-18_01-09-19.jpg` - The Akashic Records
- `photo_2025-11-04_05-38-07.jpg` - The Unmade
- `photo_2025-11-04_05-37-56.jpg` - Father's Embrace
- `photo_2025-11-04_05-37-58.jpg` - Mother and Son

## Performance Notes

### Image Optimization
Consider optimizing artwork for web:
- Resize to 1920px wide (maintains quality, reduces file size)
- Compress to 70-80% JPEG quality
- Use WebP format for better compression

### Loading Strategy
The background images load asynchronously and won't block the interface.

### Animation Performance
- Particle effects use CSS transforms (GPU-accelerated)
- Blur effects are applied once (not animated)
- Opacity transitions are smooth (1s duration)

## Tips for Best Results

1. **High contrast text**: White text on semi-transparent dark backgrounds
2. **Glass morphism**: Backdrop blur on cards maintains readability
3. **Border accents**: Cyan/purple borders separate content from background
4. **Shadow layers**: Multiple gradient overlays create depth

## Example Customizations

### Make it darker
```jsx
// Increase gradient opacity
<div className="absolute inset-0 bg-gradient-to-br from-slate-900/98 via-purple-900/95 to-slate-900/98" />
```

### Make artwork more prominent
```jsx
// Increase art opacity, reduce blur
style={{
  opacity: 0.25,
  filter: 'blur(1px) saturate(1.5)'
}}
```

### Change color scheme
```jsx
// Replace cyan with your game's primary color
// Change all instances of:
text-cyan-400 → text-emerald-400
border-cyan-500 → border-emerald-500
from-cyan-500 → from-emerald-500
```

## Credits

**Pixel Art**: Your stunning game concept art
- "The Akashic Records" - Cosmic library architecture
- "The Unmade" - Epic confrontation scene
- "Father's Embrace" - Dragon chamber with holograms
- "Mother and Son" - Dragon cave encounter

**Design Philosophy**: 
- Art enhances, doesn't overwhelm
- Readability is paramount
- Each tab tells a visual story
- Technology meets fantasy aesthetics

---

**EngAIn Pipeline** • Where AI Logic Meets Pixel Art Beauty 🎨✨
