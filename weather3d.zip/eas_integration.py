"""
Environmental Authority Subsystem - Integration Schema
How EAS connects to existing EngAIn architecture

ARCHITECTURE POSITION:
  Narrative Checkpoints (ZW extracted)
        ↓
  Environmental Authority ← YOU ARE HERE
        ↓
  ┌─────┴─────┬──────┬──────┬──────┐
  │           │      │      │      │
Weather    Visual Audio   AI   Gameplay
Systems    Systems       Systems

EAS sits BELOW narrative, ABOVE simulation.
"""

from typing import Protocol, Dict, Any
from dataclasses import dataclass
import json


# ============================================================================
# ZON4D INTEGRATION - Environmental state lives in temporal fabric
# ============================================================================

@dataclass
class EnvironmentalSnapshot:
    """
    ZON4D snapshot format for environmental state.
    This gets stored in the temporal fabric with proper anchoring.
    """
    timestamp: float  # Game time
    sky_phase: str
    lightning_phase: str
    checkpoint_id: str
    phase_start_time: float
    
    # Telemetry
    strikes_this_phase: int
    last_strike_time: float | None
    last_strike_color: str | None
    
    # Compressed rules (reference to phase definition)
    phase_rules_hash: str  # HASH32 of rule definition
    
    def to_zon4d(self) -> str:
        """
        Serialize to ZON4D format with proper temporal anchoring.
        
        This becomes part of the scene state that gets queried
        when systems ask "what are the environmental rules RIGHT NOW?"
        """
        return f"""
@anchor[tc={self.timestamp}]
env.authority {{
  sky_phase: {self.sky_phase}
  lightning_phase: {self.lightning_phase}
  checkpoint: "{self.checkpoint_id}"
  phase_start: {self.phase_start_time}
  
  telemetry {{
    strikes: {self.strikes_this_phase}
    last_strike: {self.last_strike_time or "null"}
    last_color: {self.last_strike_color or "null"}
  }}
  
  rules_hash: "{self.phase_rules_hash}"
}}
"""
    
    @staticmethod
    def from_zon4d(zon_text: str) -> "EnvironmentalSnapshot":
        """Parse from ZON4D format"""
        # TODO: Proper ZW parser integration
        # For now, simplified parsing
        pass


# ============================================================================
# AP INTEGRATION - Constraint validation layer
# ============================================================================

class APValidator:
    """
    Anti-Python constraint validation for environmental rules.
    
    AP rules declare what MUST be true, not how to make it true.
    Environmental authority enforces these as hard constraints.
    """
    
    @staticmethod
    def generate_phase_constraints(phase_name: str, rules: dict) -> str:
        """
        Generate AP constraint rules for a phase.
        These get compiled and enforced by the AP layer.
        
        Example output:
        ```
        constraint sky_phase_yellow {
          require: lightning.color in {YELLOW}
          forbid: weather.rain
          forbid: light.natural_sun
          require: temp.inversion_active
        }
        ```
        """
        constraints = [f"constraint sky_phase_{phase_name.lower()} {{"]
        
        # Lightning color constraints
        if "allowed_lightning_colors" in rules:
            colors = ", ".join(rules["allowed_lightning_colors"])
            constraints.append(f"  require: lightning.color in {{{colors}}}")
        
        # Prohibited events
        if "prohibited_events" in rules:
            for event in rules["prohibited_events"]:
                constraints.append(f"  forbid: event.{event.lower()}")
        
        # Temperature constraints
        if "temperature_gradient" in rules:
            temp = rules["temperature_gradient"]
            constraints.append(f"  require: temp.surface <= {temp['surface_celsius']}")
            constraints.append(f"  require: temp.inversion_height == {temp['inversion_height_meters']}")
        
        # Fauna constraints
        if "fauna_rules" in rules:
            fauna = rules["fauna_rules"]
            if not fauna.get("flight_permitted", True):
                constraints.append(f"  forbid: creature.flight_active")
        
        constraints.append("}")
        return "\n".join(constraints)
    
    @staticmethod
    def validate_event(event_type: str, event_data: dict, current_rules: dict) -> tuple[bool, str]:
        """
        Runtime validation: does this event violate AP constraints?
        
        This is called by EnvironmentalAuthority.validate_* methods
        before allowing any environmental event.
        """
        # Generate constraint set for current phase
        constraints = APValidator.generate_phase_constraints("runtime", current_rules)
        
        # TODO: Integrate with actual AP constraint solver
        # For now, simple checks
        
        if event_type == "lightning_strike":
            allowed_colors = current_rules.get("allowed_lightning_colors", set())
            if event_data.get("color") not in allowed_colors:
                return False, f"AP: Lightning color {event_data.get('color')} violates phase constraint"
        
        elif event_type == "creature_spawn":
            fauna_rules = current_rules.get("fauna_rules", {})
            if event_data.get("can_fly") and not fauna_rules.get("flight_permitted", True):
                return False, "AP: Flight violates inversion layer constraint"
        
        return True, ""


# ============================================================================
# GODOT INTEGRATION - Rendering client subscription
# ============================================================================

class GodotEnvironmentAdapter:
    """
    Adapter that translates Environmental Authority state
    into Godot engine commands via HTTP.
    
    Godot receives:
    - Sky shader parameters
    - Allowed VFX palette
    - Audio profile changes
    - Temperature zone overlays
    
    Godot NEVER decides environmental state.
    """
    
    def __init__(self, godot_server_url: str):
        self.godot_url = godot_server_url
        self.last_sent_state = None
    
    def on_environment_change(self, state: "EnvironmentState") -> None:
        """
        Called by Environmental Authority when state changes.
        Sends delta updates to Godot.
        """
        if self.last_sent_state and self.last_sent_state.sky_phase == state.sky_phase:
            # Only telemetry changed, no visual update needed
            return
        
        # Build Godot command packet
        command = {
            "type": "environment_update",
            "sky_phase": state.sky_phase.name,
            "palette": self._build_palette(state),
            "audio_profile": self._build_audio_profile(state),
            "temperature_zones": self._build_temp_zones(state)
        }
        
        # Send to Godot via HTTP
        self._send_to_godot(command)
        self.last_sent_state = state
    
    def _build_palette(self, state: "EnvironmentState") -> dict:
        """Convert phase rules to Godot sky shader parameters"""
        rules = state.active_rules
        return {
            "min_saturation": rules.sky_palette_min_saturation,
            "max_brightness": rules.sky_palette_max_brightness,
            "allowed_colors": [c.name for c in rules.allowed_lightning_colors]
        }
    
    def _build_audio_profile(self, state: "EnvironmentState") -> dict:
        """Convert phase rules to audio system parameters"""
        rules = state.active_rules
        return {
            "ambient_volume": rules.ambient_volume_modifier,
            "thunder_delay_range_ms": rules.thunder_delay_ms_range
        }
    
    def _build_temp_zones(self, state: "EnvironmentState") -> dict:
        """Convert temperature gradient to Godot overlay data"""
        grad = state.active_rules.temperature_gradient
        return {
            "surface_temp": grad.surface_celsius,
            "inversion_height": grad.inversion_height_meters,
            "gradient_rate": grad.rate_per_meter
        }
    
    def _send_to_godot(self, command: dict) -> None:
        """Send command to Godot via HTTP"""
        # TODO: Actual HTTP POST
        print(f"→ Godot: {json.dumps(command, indent=2)}")


# ============================================================================
# NARRATIVE EXTRACTION INTEGRATION
# ============================================================================

class NarrativeEnvironmentExtractor:
    """
    Extracts environmental checkpoints from story text.
    
    INPUT (from story):
    "The sky turned deep crimson as the final battle began."
    
    OUTPUT (ZW semantic):
    checkpoint.final_battle -> sky_phase:DEEP_CRIMSON
    
    This feeds the Environmental Authority's checkpoint mapping.
    """
    
    @staticmethod
    def extract_checkpoint_rules(chapter_text: str) -> Dict[str, str]:
        """
        Parse story text for environmental phase declarations.
        
        Looks for patterns like:
        - "sky turned [color]"
        - "lightning changed to [color]"
        - "the [event] began"
        
        Returns checkpoint_id -> sky_phase mapping
        """
        # TODO: Full ZW semantic extraction
        # For now, pattern matching
        
        import re
        checkpoints = {}
        
        # Look for explicit phase declarations
        sky_pattern = r"sky (?:turned|became) (deep )?(\w+)"
        for match in re.finditer(sky_pattern, chapter_text, re.IGNORECASE):
            color = match.group(2).upper()
            # Map to checkpoint based on context
            checkpoint_id = f"chapter_event_{len(checkpoints)}"
            
            if color == "CRIMSON" and match.group(1):
                checkpoints[checkpoint_id] = "DEEP_CRIMSON"
            elif color in {"WHITE", "YELLOW", "PURPLE", "GREEN", "RED", "BLUE"}:
                checkpoints[checkpoint_id] = color
        
        return checkpoints
    
    @staticmethod
    def build_phase_definition_from_narrative(chapter_text: str, phase: str) -> dict:
        """
        Extract phase rules from how the narrative describes the environment.
        
        If author writes: "No plants could grow under the crimson sky"
        -> flora_rules.growth_rate_modifier = 0.0
        
        If author writes: "The lightning struck only metal"
        -> strike_pattern.can_strike_water = False
        -> strike_pattern.can_strike_metal = True
        
        This is the core "story-first extraction" philosophy.
        """
        rules = {
            "allowed_lightning_colors": set(),
            "prohibited_events": set(),
            "flora_rules": {},
            "fauna_rules": {}
        }
        
        # Extract flora constraints
        if "no plants" in chapter_text.lower() or "nothing grew" in chapter_text.lower():
            rules["flora_rules"]["growth_rate_modifier"] = 0.0
        
        # Extract weather constraints
        if "no rain" in chapter_text.lower() or "never rained" in chapter_text.lower():
            rules["prohibited_events"].add("RAIN")
        
        # Extract lightning behavior
        if "lightning struck only metal" in chapter_text.lower():
            rules["strike_pattern"] = {
                "can_strike_water": False,
                "can_strike_metal": True
            }
        
        return rules


# ============================================================================
# WIRE IT ALL TOGETHER
# ============================================================================

class EngAInEnvironmentalStack:
    """
    Complete integration: Narrative -> EAS -> ZON4D -> Godot
    
    Data flow:
    1. Story text -> NarrativeExtractor -> checkpoint rules
    2. Checkpoint rules -> EnvironmentalAuthority -> current state
    3. Current state -> ZON4D -> temporal fabric persistence
    4. Current state -> GodotAdapter -> rendering updates
    5. Game events -> AP validation -> accept/reject
    """
    
    def __init__(self, authority: "EnvironmentalAuthority", godot_url: str):
        self.authority = authority
        self.godot_adapter = GodotEnvironmentAdapter(godot_url)
        self.ap_validator = APValidator()
        
        # Connect Godot to authority state changes
        self.authority.subscribe_to_changes(self.godot_adapter.on_environment_change)
    
    def ingest_chapter(self, chapter_text: str, chapter_id: str) -> None:
        """
        Process a story chapter and update environmental rules.
        
        This is called during the narrative pipeline's semantic pass.
        """
        # Extract checkpoint rules from narrative
        extractor = NarrativeEnvironmentExtractor()
        checkpoints = extractor.extract_checkpoint_rules(chapter_text)
        
        print(f"Extracted {len(checkpoints)} environmental checkpoints from {chapter_id}")
        
        # Update authority's checkpoint mapping
        for checkpoint_id, sky_phase in checkpoints.items():
            print(f"  {checkpoint_id} -> {sky_phase}")
            # TODO: Register checkpoint with authority
    
    def snapshot_to_zon4d(self, game_time: float) -> str:
        """
        Create ZON4D snapshot of current environmental state.
        This gets stored in the temporal fabric.
        """
        state = self.authority.get_current_state()
        snapshot = EnvironmentalSnapshot(
            timestamp=game_time,
            sky_phase=state.sky_phase.name,
            lightning_phase=state.lightning_phase.name,
            checkpoint_id=state.checkpoint_id,
            phase_start_time=state.phase_start_time,
            strikes_this_phase=state.strikes_this_phase,
            last_strike_time=state.last_strike_time,
            last_strike_color=state.last_strike_color.name if state.last_strike_color else None,
            phase_rules_hash="TODO_HASH32"  # TODO: Hash the ruleset
        )
        return snapshot.to_zon4d()
    
    def validate_game_event(self, event_type: str, event_data: dict) -> tuple[bool, str]:
        """
        Full validation pipeline for any environmental event.
        
        Checks both Environmental Authority business rules
        AND AP constraint satisfaction.
        """
        # First check Environmental Authority
        state = self.authority.get_current_state()
        
        if event_type == "lightning_strike":
            color = event_data.get("color")
            position = event_data.get("position")
            allowed, reason = self.authority.validate_lightning_strike(color, position)
            if not allowed:
                return False, f"EAS: {reason}"
        
        # Then check AP constraints
        rules = state.active_rules.__dict__  # Convert to dict for AP
        allowed, reason = self.ap_validator.validate_event(event_type, event_data, rules)
        if not allowed:
            return False, reason
        
        return True, ""


# ============================================================================
# EXAMPLE: COMPLETE FLOW
# ============================================================================

if __name__ == "__main__":
    from environmental_authority import EnvironmentalAuthority, LightningColor
    
    # Setup
    authority = EnvironmentalAuthority()
    authority.initialize("prologue", game_time=0.0)
    
    stack = EngAInEnvironmentalStack(authority, godot_url="http://localhost:7878")
    
    # Simulate narrative ingestion
    chapter_text = """
    The sky turned deep crimson as the final battle began.
    Lightning struck only the ancient metal spires.
    No plants could grow in the harsh cold below.
    """
    stack.ingest_chapter(chapter_text, "chapter_finale")
    
    # Simulate game event validation
    print("\n--- Validating lightning strike ---")
    event = {
        "color": LightningColor.YELLOW,
        "position": (100.0, 50.0, 0.0)
    }
    allowed, reason = stack.validate_game_event("lightning_strike", event)
    print(f"Yellow lightning: {'ALLOWED' if allowed else f'DENIED - {reason}'}")
    
    # Create ZON4D snapshot
    print("\n--- ZON4D Snapshot ---")
    snapshot = stack.snapshot_to_zon4d(game_time=1234.5)
    print(snapshot)
    
    # Advance to new phase
    print("\n--- Advancing to finale ---")
    authority.advance_checkpoint("final_battle", game_time=5000.0)
    
    # Snapshot after change
    snapshot = stack.snapshot_to_zon4d(game_time=5000.0)
    print(snapshot)
