"""
Environmental Authority Subsystem - Test Harness
Unit tests and validation for environmental rule enforcement

TESTING PHILOSOPHY:
- If a system CAN violate environmental law, it eventually WILL
- Tests prove the authority can detect and block invalid events
- Tests validate phase transition logic
- Tests ensure cross-system constraints are enforced
"""

import unittest
from typing import List, Tuple
from environmental_authority import (
    EnvironmentalAuthority,
    SkyPhase,
    LightningColor,
    LightningPhase,
    ProhibitedEvent
)


class TestEnvironmentalAuthority(unittest.TestCase):
    """Core authority behavior tests"""
    
    def setUp(self):
        """Initialize fresh authority for each test"""
        self.authority = EnvironmentalAuthority()
        self.authority.initialize("prologue", game_time=0.0)
    
    def test_initialization(self):
        """Authority starts in correct initial state"""
        state = self.authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.WHITE)
        self.assertEqual(state.lightning_phase, LightningPhase.PREDICTABLE)
        self.assertEqual(state.checkpoint_id, "prologue")
    
    def test_phase_progression(self):
        """Checkpoint advances change phase correctly"""
        result = self.authority.advance_checkpoint("act1_start", game_time=1000.0)
        self.assertTrue(result)
        
        state = self.authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.YELLOW)
        self.assertEqual(state.checkpoint_id, "act1_start")
    
    def test_lightning_color_validation_allowed(self):
        """Authority allows lightning colors in phase rules"""
        # WHITE phase allows YELLOW lightning
        allowed, _ = self.authority.validate_lightning_strike(
            LightningColor.YELLOW,
            (100.0, 50.0, 0.0)
        )
        self.assertTrue(allowed)
    
    def test_lightning_color_validation_forbidden(self):
        """Authority blocks lightning colors not in phase rules"""
        # WHITE phase does NOT allow PURPLE lightning
        allowed, reason = self.authority.validate_lightning_strike(
            LightningColor.PURPLE,
            (100.0, 50.0, 0.0)
        )
        self.assertFalse(allowed)
        self.assertIn("not allowed", reason.lower())
    
    def test_creature_spawn_validation_allowed(self):
        """Authority allows creatures in species whitelist"""
        allowed, _ = self.authority.validate_creature_spawn("ice_rabbit", can_fly=False)
        self.assertTrue(allowed)
    
    def test_creature_spawn_validation_forbidden_species(self):
        """Authority blocks forbidden species"""
        allowed, reason = self.authority.validate_creature_spawn("dragon", can_fly=False)
        self.assertFalse(allowed)
        self.assertIn("forbidden", reason.lower())
    
    def test_creature_spawn_validation_forbidden_flight(self):
        """Authority blocks flight in inversion phases"""
        # WHITE phase has inversion layer, no flight allowed
        allowed, reason = self.authority.validate_creature_spawn("storm_bird", can_fly=True)
        self.assertFalse(allowed)
        self.assertIn("flight", reason.lower())
    
    def test_harvest_validation_allowed(self):
        """Authority allows harvestable resources"""
        allowed, _ = self.authority.validate_harvest("ice_wheat")
        self.assertTrue(allowed)
    
    def test_harvest_validation_forbidden(self):
        """Authority blocks forbidden resources"""
        allowed, reason = self.authority.validate_harvest("tropical_fruit")
        self.assertFalse(allowed)
        self.assertIn("forbidden", reason.lower())
    
    def test_temperature_gradient_calculation(self):
        """Temperature varies correctly with height"""
        # WHITE phase: -15°C surface, +0.05°C per meter
        temp_surface = self.authority.get_temperature_at_height(0.0)
        temp_50m = self.authority.get_temperature_at_height(50.0)
        temp_100m = self.authority.get_temperature_at_height(100.0)
        
        self.assertAlmostEqual(temp_surface, -15.0)
        self.assertAlmostEqual(temp_50m, -12.5)  # -15 + 50*0.05
        self.assertAlmostEqual(temp_100m, -10.0)  # -15 + 100*0.05


class TestPhaseTransitions(unittest.TestCase):
    """Test phase change behavior"""
    
    def setUp(self):
        self.authority = EnvironmentalAuthority()
        self.authority.initialize("prologue", game_time=0.0)
    
    def test_white_to_yellow_transition(self):
        """Early phase transition works"""
        self.authority.advance_checkpoint("act1_start", game_time=1000.0)
        state = self.authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.YELLOW)
    
    def test_yellow_to_deep_crimson_transition(self):
        """Can skip phases in narrative progression"""
        # Advance to yellow first
        self.authority.advance_checkpoint("act1_start", game_time=1000.0)
        
        # Then jump to crimson (narrative emergency)
        self.authority.advance_checkpoint("final_battle", game_time=5000.0)
        state = self.authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.DEEP_CRIMSON)
    
    def test_lightning_phase_changes_with_sky_phase(self):
        """Lightning behavior mode updates with phase"""
        # WHITE = PREDICTABLE
        state = self.authority.get_current_state()
        self.assertEqual(state.lightning_phase, LightningPhase.PREDICTABLE)
        
        # YELLOW = still PREDICTABLE
        self.authority.advance_checkpoint("act1_start", game_time=1000.0)
        state = self.authority.get_current_state()
        self.assertEqual(state.lightning_phase, LightningPhase.PREDICTABLE)
        
        # DEEP_CRIMSON = EVENT_TRIGGERED
        self.authority.advance_checkpoint("final_battle", game_time=5000.0)
        state = self.authority.get_current_state()
        self.assertEqual(state.lightning_phase, LightningPhase.EVENT_TRIGGERED)


class TestCrossSystemConstraints(unittest.TestCase):
    """Test constraints that span multiple systems"""
    
    def setUp(self):
        self.authority = EnvironmentalAuthority()
    
    def test_deep_crimson_all_constraints(self):
        """DEEP_CRIMSON phase enforces all its constraints"""
        self.authority.initialize("final_battle", game_time=0.0)
        state = self.authority.get_current_state()
        
        # Only CRIMSON/BLACK lightning allowed
        self.assertIn(LightningColor.CRIMSON, state.active_rules.allowed_lightning_colors)
        self.assertNotIn(LightningColor.YELLOW, state.active_rules.allowed_lightning_colors)
        
        # Prohibited events
        self.assertIn(ProhibitedEvent.RAIN, state.active_rules.prohibited_events)
        self.assertIn(ProhibitedEvent.NATURAL_SUNLIGHT, state.active_rules.prohibited_events)
        
        # Flora rules
        self.assertEqual(state.active_rules.flora_rules.growth_rate_modifier, 0.0)
        self.assertIn("void_crystal", state.active_rules.flora_rules.harvestable_resources)
        
        # Fauna rules
        self.assertEqual(state.active_rules.fauna_rules.aggression_modifier, 1.0)
        self.assertFalse(state.active_rules.fauna_rules.flight_permitted)
    
    def test_water_strike_constraint_variation(self):
        """Water strike rules vary by phase"""
        # WHITE phase: can strike water
        self.authority.initialize("prologue", game_time=0.0)
        state = self.authority.get_current_state()
        self.assertTrue(state.active_rules.strike_pattern.can_strike_water)
        
        # DEEP_CRIMSON phase: cannot strike water
        self.authority.initialize("final_battle", game_time=0.0)
        state = self.authority.get_current_state()
        self.assertFalse(state.active_rules.strike_pattern.can_strike_water)
    
    def test_temperature_inversion_enforcement(self):
        """Inversion layer blocks flight in early phases"""
        self.authority.initialize("prologue", game_time=0.0)
        
        # Check temperature actually inverts
        temp_ground = self.authority.get_temperature_at_height(0.0)
        temp_high = self.authority.get_temperature_at_height(100.0)
        self.assertLess(temp_ground, temp_high)  # Warmer above = inversion
        
        # Check flight blocked
        allowed, _ = self.authority.validate_creature_spawn("bird", can_fly=True)
        self.assertFalse(allowed)


class TestRuleEnforcement(unittest.TestCase):
    """Test that rules actually prevent violations"""
    
    def setUp(self):
        self.authority = EnvironmentalAuthority()
        self.authority.initialize("prologue", game_time=0.0)
    
    def test_artist_cannot_spawn_wrong_color_lightning(self):
        """Visual system cannot create purple lightning in WHITE phase"""
        allowed, reason = self.authority.validate_lightning_strike(
            LightningColor.PURPLE,
            (100.0, 50.0, 0.0)
        )
        self.assertFalse(allowed)
        self.assertIn("PURPLE", reason)
        self.assertIn("not allowed", reason)
    
    def test_designer_cannot_add_forbidden_creature(self):
        """Gameplay cannot spawn dragons in early phases"""
        allowed, reason = self.authority.validate_creature_spawn("dragon", can_fly=False)
        self.assertFalse(allowed)
        self.assertIn("dragon", reason.lower())
    
    def test_writer_cannot_add_warm_breeze(self):
        """Narrative cannot create ground-level warmth in inversion phase"""
        # Check that surface is cold
        temp = self.authority.get_temperature_at_height(0.0)
        self.assertLess(temp, 0.0)  # Below freezing
        
        # Check warm air only exists above inversion layer
        temp_high = self.authority.get_temperature_at_height(150.0)
        self.assertGreater(temp_high, temp)
    
    def test_ai_cannot_use_flying_enemies_in_inversion(self):
        """AI behavior system cannot spawn flying creatures in inversion"""
        allowed, reason = self.authority.validate_creature_spawn("flying_horror", can_fly=True)
        self.assertFalse(allowed)
        self.assertIn("flight", reason.lower())


class TestStateSubscription(unittest.TestCase):
    """Test callback system for state changes"""
    
    def setUp(self):
        self.authority = EnvironmentalAuthority()
        self.authority.initialize("prologue", game_time=0.0)
        self.notifications: List[Tuple[SkyPhase, float]] = []
    
    def _on_state_change(self, state):
        """Record state changes"""
        self.notifications.append((state.sky_phase, state.phase_start_time))
    
    def test_subscribers_notified_on_phase_change(self):
        """Callbacks fire when phase changes"""
        self.authority.subscribe_to_changes(self._on_state_change)
        
        # Advance phase
        self.authority.advance_checkpoint("act1_start", game_time=1000.0)
        
        # Check notification received
        self.assertEqual(len(self.notifications), 1)
        self.assertEqual(self.notifications[0][0], SkyPhase.YELLOW)
        self.assertEqual(self.notifications[0][1], 1000.0)
    
    def test_multiple_subscribers(self):
        """Multiple systems can subscribe"""
        notifications_a = []
        notifications_b = []
        
        self.authority.subscribe_to_changes(lambda s: notifications_a.append(s.sky_phase))
        self.authority.subscribe_to_changes(lambda s: notifications_b.append(s.sky_phase))
        
        self.authority.advance_checkpoint("act1_start", game_time=1000.0)
        
        self.assertEqual(len(notifications_a), 1)
        self.assertEqual(len(notifications_b), 1)


class TestEdgeCases(unittest.TestCase):
    """Test boundary conditions and error cases"""
    
    def test_cannot_query_uninitialized_authority(self):
        """Authority must be initialized before use"""
        authority = EnvironmentalAuthority()
        
        with self.assertRaises(RuntimeError):
            authority.get_current_state()
    
    def test_invalid_checkpoint_defaults_to_white(self):
        """Unknown checkpoints default to safe state"""
        authority = EnvironmentalAuthority()
        authority.initialize("unknown_checkpoint_xyz", game_time=0.0)
        
        state = authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.WHITE)
    
    def test_temperature_above_inversion_layer(self):
        """Temperature calculation works above inversion height"""
        authority = EnvironmentalAuthority()
        authority.initialize("prologue", game_time=0.0)
        
        # WHITE phase: inversion at 100m
        temp_at_inversion = authority.get_temperature_at_height(100.0)
        temp_above = authority.get_temperature_at_height(200.0)
        
        # Temperature should be constant above inversion
        self.assertEqual(temp_at_inversion, temp_above)


class TestNarrativeIntegration(unittest.TestCase):
    """Test integration with narrative extraction"""
    
    def test_checkpoint_mapping_from_story(self):
        """Checkpoints extracted from narrative map to phases"""
        authority = EnvironmentalAuthority()
        
        # Simulate narrative system saying "we reached this checkpoint"
        authority.initialize("prologue", game_time=0.0)
        state = authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.WHITE)
        
        authority.advance_checkpoint("act1_start", game_time=1000.0)
        state = authority.get_current_state()
        self.assertEqual(state.sky_phase, SkyPhase.YELLOW)
    
    def test_phase_enforces_what_story_says(self):
        """
        CRITICAL TEST: Authority enforces what narrative actually contains.
        
        If author writes all abilities in Chapter 1, authority reports this
        but enforces it. The game might be boring, but it matches the story.
        """
        authority = EnvironmentalAuthority()
        
        # Story says "prologue has yellow lightning"
        authority.initialize("prologue", game_time=0.0)
        
        # Story never mentions purple lightning in prologue
        # So authority MUST block it
        allowed, _ = authority.validate_lightning_strike(
            LightningColor.PURPLE,
            (100.0, 50.0, 0.0)
        )
        self.assertFalse(allowed)
        
        # Authority enforces narrative truth, not game design wishes


# ============================================================================
# VIOLATION DETECTION TESTS
# ============================================================================

class TestViolationDetection(unittest.TestCase):
    """
    Test the authority can detect common violation patterns.
    These are things that WILL happen if systems aren't gated.
    """
    
    def setUp(self):
        self.authority = EnvironmentalAuthority()
        self.authority.initialize("prologue", game_time=0.0)
        self.violations_detected = []
    
    def attempt_violation(self, description: str, validation_func, *args) -> bool:
        """Try a violation and record if it was caught"""
        allowed, reason = validation_func(*args)
        if not allowed:
            self.violations_detected.append(description)
        return not allowed  # Return True if violation was caught
    
    def test_detect_color_violations(self):
        """Catch artists using wrong lightning colors"""
        caught = self.attempt_violation(
            "Artist used purple lightning in WHITE phase",
            self.authority.validate_lightning_strike,
            LightningColor.PURPLE,
            (100.0, 50.0, 0.0)
        )
        self.assertTrue(caught)
    
    def test_detect_species_violations(self):
        """Catch designers spawning forbidden creatures"""
        caught = self.attempt_violation(
            "Designer spawned dragon in early phase",
            self.authority.validate_creature_spawn,
            "dragon",
            False
        )
        self.assertTrue(caught)
    
    def test_detect_flight_violations(self):
        """Catch AI using flying enemies during inversion"""
        caught = self.attempt_violation(
            "AI spawned flying enemy during inversion anomaly",
            self.authority.validate_creature_spawn,
            "flying_horror",
            True
        )
        self.assertTrue(caught)
    
    def test_detect_harvest_violations(self):
        """Catch crafting system generating forbidden resources"""
        caught = self.attempt_violation(
            "Crafting system generated tropical fruit in ice phase",
            self.authority.validate_harvest,
            "tropical_fruit"
        )
        self.assertTrue(caught)
    
    def test_all_common_violations_caught(self):
        """Run all violation tests and verify detection"""
        self.test_detect_color_violations()
        self.test_detect_species_violations()
        self.test_detect_flight_violations()
        self.test_detect_harvest_violations()
        
        # All should have been caught
        self.assertEqual(len(self.violations_detected), 4)
        print("\nViolations successfully detected:")
        for v in self.violations_detected:
            print(f"  ✓ {v}")


# ============================================================================
# INTEGRATION TEST SUITE
# ============================================================================

class TestFullIntegration(unittest.TestCase):
    """
    Test complete flow: narrative -> authority -> validation -> rendering
    """
    
    def test_complete_phase_cycle(self):
        """Simulate progression through multiple phases"""
        authority = EnvironmentalAuthority()
        
        # Start
        authority.initialize("prologue", game_time=0.0)
        self.assertEqual(authority.get_current_state().sky_phase, SkyPhase.WHITE)
        
        # Act 1
        authority.advance_checkpoint("act1_start", game_time=1000.0)
        self.assertEqual(authority.get_current_state().sky_phase, SkyPhase.YELLOW)
        
        # Climax
        authority.advance_checkpoint("act1_climax", game_time=5000.0)
        self.assertEqual(authority.get_current_state().sky_phase, SkyPhase.PURPLE)
        
        # Finale
        authority.advance_checkpoint("final_battle", game_time=10000.0)
        self.assertEqual(authority.get_current_state().sky_phase, SkyPhase.DEEP_CRIMSON)
    
    def test_rules_change_with_phases(self):
        """Phase changes actually update active rules"""
        authority = EnvironmentalAuthority()
        
        # WHITE phase
        authority.initialize("prologue", game_time=0.0)
        state = authority.get_current_state()
        white_colors = set(state.active_rules.allowed_lightning_colors)
        
        # YELLOW phase
        authority.advance_checkpoint("act1_start", game_time=1000.0)
        state = authority.get_current_state()
        yellow_colors = set(state.active_rules.allowed_lightning_colors)
        
        # Rules should be consistent (both allow YELLOW in early phases)
        self.assertEqual(white_colors, yellow_colors)
        
        # DEEP_CRIMSON phase
        authority.advance_checkpoint("final_battle", game_time=5000.0)
        state = authority.get_current_state()
        crimson_colors = set(state.active_rules.allowed_lightning_colors)
        
        # Rules should be different
        self.assertNotEqual(white_colors, crimson_colors)


def run_all_tests():
    """Run complete test suite"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestEnvironmentalAuthority))
    suite.addTests(loader.loadTestsFromTestCase(TestPhaseTransitions))
    suite.addTests(loader.loadTestsFromTestCase(TestCrossSystemConstraints))
    suite.addTests(loader.loadTestsFromTestCase(TestRuleEnforcement))
    suite.addTests(loader.loadTestsFromTestCase(TestStateSubscription))
    suite.addTests(loader.loadTestsFromTestCase(TestEdgeCases))
    suite.addTests(loader.loadTestsFromTestCase(TestNarrativeIntegration))
    suite.addTests(loader.loadTestsFromTestCase(TestViolationDetection))
    suite.addTests(loader.loadTestsFromTestCase(TestFullIntegration))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)
