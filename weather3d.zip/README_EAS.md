# Environmental Authority Subsystem (EAS)

**Single source of truth for atmospheric state in EngAIn**

## What This Is

The Environmental Authority Subsystem (EAS) is a **deterministic state authority** that sits between narrative checkpoints and all simulation systems (weather, visuals, audio, AI, gameplay).

**This is NOT:**
- A weather simulator
- A probability engine
- A per-biome controller
- A visual effects manager
- A physics model

**This IS:**
- A single source of truth for environmental rules
- A dispatcher that tells other systems what rules apply
- A gatekeeper that prevents invalid events

## Core Architecture

```
Narrative Checkpoints (from story)
        ↓
Environmental Authority ← YOU ARE HERE
        ↓
  ┌─────┴─────┬──────┬──────┬──────┐
  │           │      │      │      │
Weather    Visual Audio   AI   Gameplay
Systems    Systems       Systems
```

## The Golden Rule

> **If a system decides environmental behavior without consulting the Environmental Authority, it is a bug.**

## Quick Start

```python
from environmental_authority import EnvironmentalAuthority, LightningColor

# Initialize
authority = EnvironmentalAuthority()
authority.initialize("prologue", game_time=0.0)

# Query current state
state = authority.get_current_state()
print(f"Sky phase: {state.sky_phase.name}")
print(f"Lightning mode: {state.lightning_phase.name}")

# Validate events BEFORE they happen
allowed, reason = authority.validate_lightning_strike(
    LightningColor.YELLOW,
    (100.0, 50.0, 0.0)
)
if not allowed:
    print(f"Cannot spawn lightning: {reason}")
```

## Integration Patterns

### Visual System (VFX/Renderer)

```python
class VFXSystem:
    def __init__(self, authority: EnvironmentalAuthority):
        self.authority = authority
        # Subscribe to state changes
        authority.subscribe_to_changes(self._on_environment_change)
    
    def _on_environment_change(self, state):
        # Update rendering based on new rules
        rules = state.active_rules
        self.sky_shader.set_palette(rules.allowed_lightning_colors)
        self.thunder_system.set_delay_range(rules.thunder_delay_ms_range)
    
    def spawn_lightning(self, color, position):
        # ALWAYS validate before spawning
        allowed, reason = self.authority.validate_lightning_strike(color, position)
        if not allowed:
            log.error(f"Lightning blocked: {reason}")
            return False
        
        # Spawn the effect
        self._create_lightning_vfx(color, position)
        return True
```

### Gameplay System

```python
class GameplaySystem:
    def __init__(self, authority: EnvironmentalAuthority):
        self.authority = authority
    
    def attempt_harvest(self, resource: str):
        # Check if legal in current phase
        allowed, reason = self.authority.validate_harvest(resource)
        if not allowed:
            self.show_ui_message(f"Cannot harvest: {reason}")
            return False
        
        # Execute harvest
        self.player_inventory.add(resource)
        return True
    
    def calculate_creature_ai(self, creature):
        # Get current aggression modifier
        state = self.authority.get_current_state()
        aggression = state.active_rules.fauna_rules.aggression_modifier
        
        # Apply to AI behavior
        creature.aggression_level *= aggression
```

### AI/Creature System

```python
class CreatureSpawner:
    def __init__(self, authority: EnvironmentalAuthority):
        self.authority = authority
    
    def spawn_creature(self, species: str, position: tuple, can_fly: bool):
        # Validate spawn is legal
        allowed, reason = self.authority.validate_creature_spawn(species, can_fly)
        if not allowed:
            log.warning(f"Spawn blocked: {reason}")
            return None
        
        # Create creature
        creature = self._instantiate_creature(species, position)
        return creature
```

### Narrative System

```python
class NarrativeEngine:
    def __init__(self, authority: EnvironmentalAuthority):
        self.authority = authority
    
    def reach_checkpoint(self, checkpoint_id: str, game_time: float):
        # Notify authority of narrative progression
        success = self.authority.advance_checkpoint(checkpoint_id, game_time)
        if success:
            log.info(f"Environment advanced to {checkpoint_id}")
        else:
            log.error(f"Invalid checkpoint transition: {checkpoint_id}")
```

## Phase Definitions

Each sky phase has explicit rules that other systems must obey:

### WHITE Phase (Early Game)
- **Lightning**: Yellow only, predictable 47-min cycle
- **Temperature**: -15°C surface, inversion layer at 100m
- **Flora**: Slow growth (0.5x), ice_wheat/frozen_berries harvestable
- **Fauna**: No flight permitted, only ice_rabbit/snow_fox
- **Prohibited**: Natural sunlight, ground-level warmth

### YELLOW Phase (Mid Early)
- **Lightning**: Yellow only, slight variance
- **Temperature**: -10°C surface, inversion layer at 100m
- **Flora**: Medium growth (0.7x), lightning_grain/static_herb
- **Fauna**: No flight, charged_wolf/storm_bird allowed
- **Prohibited**: Natural sunlight

### DEEP_CRIMSON Phase (Finale)
- **Lightning**: Crimson/Black, event-triggered only
- **Temperature**: -25°C surface, sharp inversion at 50m
- **Flora**: No growth (0.0x), void_crystal/crimson_ash only
- **Fauna**: Maximum aggression (+1.0), void_spawn only, no flight
- **Prohibited**: Rain, sunlight, calm winds, ground warmth

## ZON4D Integration

Environmental state persists in the temporal fabric:

```python
from eas_integration import EngAInEnvironmentalStack

stack = EngAInEnvironmentalStack(authority, godot_url="http://localhost:7878")

# Create temporal snapshot
snapshot = stack.snapshot_to_zon4d(game_time=1234.5)

# Result:
# @anchor[tc=1234.5]
# env.authority {
#   sky_phase: WHITE
#   lightning_phase: PREDICTABLE
#   checkpoint: "prologue"
#   ...
# }
```

## AP (Anti-Python) Integration

Environmental rules become AP constraints:

```python
from eas_integration import APValidator

# Generate constraint rules for a phase
constraints = APValidator.generate_phase_constraints("yellow", rules_dict)

# Result:
# constraint sky_phase_yellow {
#   require: lightning.color in {YELLOW}
#   forbid: event.natural_sunlight
#   require: temp.surface <= -10.0
#   forbid: creature.flight_active
# }

# Runtime validation
valid, reason = APValidator.validate_event("lightning_strike", event_data, rules)
```

## Godot Integration

Environmental state drives rendering via HTTP:

```python
from eas_integration import GodotEnvironmentAdapter

adapter = GodotEnvironmentAdapter("http://localhost:7878")
authority.subscribe_to_changes(adapter.on_environment_change)

# When phase changes, Godot receives:
# {
#   "type": "environment_update",
#   "sky_phase": "YELLOW",
#   "palette": {
#     "min_saturation": 0.0,
#     "max_brightness": 1.0,
#     "allowed_colors": ["YELLOW"]
#   },
#   "audio_profile": {
#     "ambient_volume": 1.0,
#     "thunder_delay_range_ms": [0, 3000]
#   },
#   "temperature_zones": {
#     "surface_temp": -10.0,
#     "inversion_height": 100.0,
#     "gradient_rate": 0.05
#   }
# }
```

## Narrative Extraction

Story text becomes environmental rules:

```python
from eas_integration import NarrativeEnvironmentExtractor

chapter_text = """
The sky turned deep crimson as the final battle began.
Lightning struck only the ancient metal spires.
No plants could grow in the harsh cold below.
"""

# Extract checkpoint mappings
extractor = NarrativeEnvironmentExtractor()
checkpoints = extractor.extract_checkpoint_rules(chapter_text)
# Result: {"chapter_event_0": "DEEP_CRIMSON"}

# Extract phase rules from narrative
rules = extractor.build_phase_definition_from_narrative(chapter_text, "DEEP_CRIMSON")
# Result: {
#   "flora_rules": {"growth_rate_modifier": 0.0},
#   "prohibited_events": set(),
#   "strike_pattern": {
#     "can_strike_water": False,
#     "can_strike_metal": True
#   }
# }
```

## Testing

Comprehensive test suite validates environmental law enforcement:

```bash
python test_environmental_authority.py

# Tests cover:
# - Phase transitions
# - Lightning color validation
# - Creature spawn validation
# - Harvest validation
# - Temperature calculations
# - Cross-system constraints
# - Violation detection
# - Callback subscriptions
```

Key tests:

```python
def test_artist_cannot_spawn_wrong_color_lightning(self):
    """Visual system cannot create purple lightning in WHITE phase"""
    allowed, reason = self.authority.validate_lightning_strike(
        LightningColor.PURPLE,
        (100.0, 50.0, 0.0)
    )
    self.assertFalse(allowed)

def test_ai_cannot_use_flying_enemies_in_inversion(self):
    """AI behavior system cannot spawn flying creatures in inversion"""
    allowed, reason = self.authority.validate_creature_spawn(
        "flying_horror", 
        can_fly=True
    )
    self.assertFalse(allowed)
```

## Common Violations (All Caught by EAS)

Without EAS, these violations WILL happen:

1. **Artist spawns blue lightning during Yellow phase**
   - ✓ Caught by `validate_lightning_strike()`

2. **Designer adds rain for mood during Crimson phase**
   - ✓ Caught by checking `prohibited_events` in rules

3. **Writer scripts warm breeze at ground level during inversion**
   - ✓ Caught by `get_temperature_at_height()` enforcement

4. **AI uses flying enemies during inversion anomaly**
   - ✓ Caught by `validate_creature_spawn()` with flight check

5. **Crafting system generates tropical fruit in ice phase**
   - ✓ Caught by `validate_harvest()` checking harvestable resources

## File Structure

```
environmental_authority.py    # Core authority implementation
├─ EnvironmentalAuthority     # Main authority class
├─ SkyPhase                   # Phase enumeration
├─ LightningPhase             # Lightning behavior modes
├─ RuleSet                    # Phase-specific constraints
└─ EnvironmentState           # Current authoritative state

eas_integration.py            # Integration with EngAIn systems
├─ EnvironmentalSnapshot      # ZON4D serialization
├─ APValidator               # AP constraint generation
├─ GodotEnvironmentAdapter   # Godot rendering bridge
├─ NarrativeEnvironmentExtractor  # Story extraction
└─ EngAInEnvironmentalStack  # Complete integration

test_environmental_authority.py  # Comprehensive test suite
├─ TestEnvironmentalAuthority    # Core functionality
├─ TestPhaseTransitions         # Phase change behavior
├─ TestCrossSystemConstraints   # Multi-system rules
├─ TestRuleEnforcement          # Violation blocking
└─ TestViolationDetection       # Common error patterns
```

## Next Steps

To integrate EAS into your existing EngAIn pipeline:

1. **Connect to Narrative Pipeline**
   ```python
   # In your semantic extraction pass:
   checkpoints = extract_checkpoints_from_chapter(chapter_text)
   for checkpoint_id, sky_phase in checkpoints.items():
       authority.register_checkpoint_mapping(checkpoint_id, sky_phase)
   ```

2. **Update Godot Rendering**
   ```python
   # In your Python→Godot bridge:
   adapter = GodotEnvironmentAdapter(godot_server_url)
   authority.subscribe_to_changes(adapter.on_environment_change)
   ```

3. **Gate All Environmental Events**
   ```python
   # Before ANY environmental event:
   allowed, reason = authority.validate_X(...)
   if not allowed:
       log_violation(reason)
       return False
   ```

4. **Add AP Constraints**
   ```python
   # Generate AP rules from phase definitions:
   for phase, rules in phase_definitions.items():
       ap_rules = APValidator.generate_phase_constraints(phase, rules)
       ap_system.compile_constraint_set(ap_rules)
   ```

## Philosophy

The key insight: **Narrative is authoritative, not design documents.**

If an author writes all magic abilities into Chapter 1, the engine reports this creates a boring game but **enforces what the story actually says**.

This "authoring engine" approach means:
- Story = source of truth
- EAS = law enforcement
- Other systems = obedient citizens

The Environmental Authority doesn't simulate weather. It **declares law** and **enforces compliance**.

## Questions?

Common questions answered:

**Q: Why not just use game state flags?**
A: State flags don't validate constraints across systems. EAS actively prevents violations.

**Q: Where does lightning live?**
A: Lightning is a **mode inside EAS**, not its own subsystem. Lightning events are emitted by the authority and consumed by VFX/Audio/Gameplay.

**Q: Auto-scheduling or manual control?**
A: Both. Early phases use deterministic cycles. Late phases use event triggers. The authority manages both modes.

**Q: How does this scale to Books 2-7?**
A: Swap RuleSets, add new SkyPhases, introduce competing authorities. The core architecture remains stable.

**Q: Can systems still be creative?**
A: Yes! Within the allowed palette. Visual system chooses WHERE yellow lightning strikes, but cannot make it purple.

## License

Part of the EngAIn project. See main project README for details.
