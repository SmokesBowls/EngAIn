"""
Environmental Authority Subsystem (EAS)
Single source of truth for atmospheric state in EngAIn

This is NOT a simulation. This is a deterministic state authority.
Other systems query this - they do not decide independently.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Set, List, Optional, Callable
from datetime import timedelta


class SkyPhase(Enum):
    """Macro environmental modes"""
    WHITE = auto()
    YELLOW = auto()
    PURPLE = auto()
    GREEN = auto()
    RED = auto()
    BLUE = auto()
    DEEP_CRIMSON = auto()
    BLACK = auto()


class LightningColor(Enum):
    """Lightning telemetry channels"""
    YELLOW = auto()
    PURPLE = auto()
    GREEN = auto()
    RED = auto()
    BLUE = auto()
    CRIMSON = auto()
    BLACK = auto()


class LightningPhase(Enum):
    """Lightning behavior modes within sky phases"""
    DORMANT = auto()           # No lightning
    PREDICTABLE = auto()       # 47-min cycle (White/Yellow)
    SEMI_RANDOM = auto()       # Rule-bounded chaos (Purple-Blue)
    EVENT_TRIGGERED = auto()   # Narrative/stress driven (Crimson/Black)


class ProhibitedEvent(Enum):
    """Events that can be explicitly forbidden by phase rules"""
    RAIN = auto()
    NATURAL_SUNLIGHT = auto()
    CALM_WINDS = auto()
    GROUND_LEVEL_WARMTH = auto()
    FLYING_CREATURES = auto()
    NORMAL_CROPS = auto()


@dataclass
class TemperatureGradient:
    """Vertical temperature profile"""
    surface_celsius: float
    inversion_height_meters: float
    rate_per_meter: float  # Positive = warmer above
    
    def get_temp_at_height(self, height_meters: float) -> float:
        """Calculate temperature at given height"""
        if height_meters <= self.inversion_height_meters:
            return self.surface_celsius + (height_meters * self.rate_per_meter)
        return self.surface_celsius + (self.inversion_height_meters * self.rate_per_meter)


@dataclass
class StrikePattern:
    """Lightning frequency and distribution rules"""
    base_frequency_per_hour: float
    variance_factor: float  # 0.0 = deterministic, 1.0 = ±100% variance
    spatial_clustering: bool
    can_strike_water: bool
    can_strike_metal: bool


@dataclass
class FloraRules:
    """Constraints on plant behavior"""
    growth_rate_modifier: float
    harvestable_resources: Set[str]
    forbidden_resources: Set[str]
    mutation_allowed: bool


@dataclass
class FaunaRules:
    """Constraints on creature behavior"""
    aggression_modifier: float  # -1.0 = pacified, +1.0 = enraged
    allowed_species: Set[str]
    forbidden_species: Set[str]
    flight_permitted: bool


@dataclass
class RuleSet:
    """
    Phase-specific constraints that other systems must obey.
    This is NOT behavior - it's the law.
    """
    allowed_lightning_colors: Set[LightningColor]
    strike_pattern: StrikePattern
    temperature_gradient: TemperatureGradient
    flora_rules: FloraRules
    fauna_rules: FaunaRules
    prohibited_events: Set[ProhibitedEvent]
    
    # Visual constraints
    sky_palette_min_saturation: float = 0.0
    sky_palette_max_brightness: float = 1.0
    
    # Audio constraints
    ambient_volume_modifier: float = 1.0
    thunder_delay_ms_range: tuple[int, int] = (0, 3000)


@dataclass
class EnvironmentState:
    """
    The authoritative current state.
    This is what all other systems query.
    """
    sky_phase: SkyPhase
    lightning_phase: LightningPhase
    active_rules: RuleSet
    checkpoint_id: str
    phase_start_time: float  # Game time when this phase began
    
    # Telemetry (read-only for other systems)
    last_strike_time: Optional[float] = None
    last_strike_color: Optional[LightningColor] = None
    strikes_this_phase: int = 0


class EnvironmentalAuthority:
    """
    The single source of truth for atmospheric state.
    
    OTHER SYSTEMS:
    - Query this for current rules
    - Subscribe to state changes
    - Request validation before events
    - NEVER decide environmental behavior independently
    
    RULE: If a system decides environmental behavior without consulting
          this authority, it is a BUG.
    """
    
    def __init__(self):
        self._current_state: Optional[EnvironmentState] = None
        self._state_change_callbacks: List[Callable[[EnvironmentState], None]] = []
        self._phase_definitions = self._build_phase_definitions()
    
    def _build_phase_definitions(self) -> dict[SkyPhase, RuleSet]:
        """
        Define the law for each phase.
        This is where narrative constraints become executable rules.
        """
        return {
            SkyPhase.WHITE: RuleSet(
                allowed_lightning_colors={LightningColor.YELLOW},
                strike_pattern=StrikePattern(
                    base_frequency_per_hour=1.28,  # 47-min cycle ≈ 1.28/hr
                    variance_factor=0.0,  # Perfectly predictable
                    spatial_clustering=False,
                    can_strike_water=True,
                    can_strike_metal=True
                ),
                temperature_gradient=TemperatureGradient(
                    surface_celsius=-15.0,
                    inversion_height_meters=100.0,
                    rate_per_meter=0.05  # Gets warmer above
                ),
                flora_rules=FloraRules(
                    growth_rate_modifier=0.5,
                    harvestable_resources={"ice_wheat", "frozen_berries"},
                    forbidden_resources={"tropical_fruit"},
                    mutation_allowed=False
                ),
                fauna_rules=FaunaRules(
                    aggression_modifier=0.0,
                    allowed_species={"ice_rabbit", "snow_fox"},
                    forbidden_species={"dragon"},
                    flight_permitted=False  # Inversion layer blocks flight
                ),
                prohibited_events={
                    ProhibitedEvent.NATURAL_SUNLIGHT,
                    ProhibitedEvent.GROUND_LEVEL_WARMTH
                }
            ),
            
            SkyPhase.YELLOW: RuleSet(
                allowed_lightning_colors={LightningColor.YELLOW},
                strike_pattern=StrikePattern(
                    base_frequency_per_hour=1.28,
                    variance_factor=0.1,  # Slight variance
                    spatial_clustering=True,
                    can_strike_water=True,
                    can_strike_metal=True
                ),
                temperature_gradient=TemperatureGradient(
                    surface_celsius=-10.0,
                    inversion_height_meters=100.0,
                    rate_per_meter=0.05
                ),
                flora_rules=FloraRules(
                    growth_rate_modifier=0.7,
                    harvestable_resources={"lightning_grain", "static_herb"},
                    forbidden_resources=set(),
                    mutation_allowed=True
                ),
                fauna_rules=FaunaRules(
                    aggression_modifier=0.2,
                    allowed_species={"charged_wolf", "storm_bird"},
                    forbidden_species={"dragon"},
                    flight_permitted=False
                ),
                prohibited_events={ProhibitedEvent.NATURAL_SUNLIGHT}
            ),
            
            SkyPhase.DEEP_CRIMSON: RuleSet(
                allowed_lightning_colors={LightningColor.CRIMSON, LightningColor.BLACK},
                strike_pattern=StrikePattern(
                    base_frequency_per_hour=0.0,  # Event-triggered only
                    variance_factor=0.0,
                    spatial_clustering=True,
                    can_strike_water=False,
                    can_strike_metal=True
                ),
                temperature_gradient=TemperatureGradient(
                    surface_celsius=-25.0,
                    inversion_height_meters=50.0,
                    rate_per_meter=0.1
                ),
                flora_rules=FloraRules(
                    growth_rate_modifier=0.0,
                    harvestable_resources={"void_crystal", "crimson_ash"},
                    forbidden_resources={"normal_crops"},
                    mutation_allowed=True
                ),
                fauna_rules=FaunaRules(
                    aggression_modifier=1.0,  # Maximum aggression
                    allowed_species={"void_spawn"},
                    forbidden_species={"normal_animals"},
                    flight_permitted=False
                ),
                prohibited_events={
                    ProhibitedEvent.RAIN,
                    ProhibitedEvent.NATURAL_SUNLIGHT,
                    ProhibitedEvent.CALM_WINDS,
                    ProhibitedEvent.GROUND_LEVEL_WARMTH
                }
            )
            
            # TODO: Define PURPLE, GREEN, RED, BLUE, BLACK phases
        }
    
    def initialize(self, checkpoint_id: str, game_time: float) -> None:
        """Bootstrap the authority with initial state"""
        initial_phase = self._checkpoint_to_phase(checkpoint_id)
        self._current_state = EnvironmentState(
            sky_phase=initial_phase,
            lightning_phase=self._determine_lightning_phase(initial_phase),
            active_rules=self._phase_definitions[initial_phase],
            checkpoint_id=checkpoint_id,
            phase_start_time=game_time
        )
        self._notify_state_change()
    
    def advance_checkpoint(self, new_checkpoint_id: str, game_time: float) -> bool:
        """
        Narrative progression triggers phase change.
        Returns True if state changed, False if invalid.
        """
        if not self._current_state:
            raise RuntimeError("Authority not initialized")
        
        new_phase = self._checkpoint_to_phase(new_checkpoint_id)
        
        # Validate transition is legal
        if not self._is_valid_transition(self._current_state.sky_phase, new_phase):
            return False
        
        self._current_state = EnvironmentState(
            sky_phase=new_phase,
            lightning_phase=self._determine_lightning_phase(new_phase),
            active_rules=self._phase_definitions[new_phase],
            checkpoint_id=new_checkpoint_id,
            phase_start_time=game_time
        )
        self._notify_state_change()
        return True
    
    def validate_lightning_strike(
        self, 
        color: LightningColor, 
        target_position: tuple[float, float, float]
    ) -> tuple[bool, str]:
        """
        Gatekeeper: Can this lightning event happen?
        Returns (allowed, reason_if_denied)
        """
        if not self._current_state:
            return False, "Authority not initialized"
        
        rules = self._current_state.active_rules
        
        # Check color is allowed
        if color not in rules.allowed_lightning_colors:
            return False, f"Color {color.name} not allowed in phase {self._current_state.sky_phase.name}"
        
        # Check target material constraints
        x, y, z = target_position
        # TODO: Query terrain system for material at position
        # For now, simplified check
        if z < 0 and not rules.strike_pattern.can_strike_water:
            return False, "Cannot strike water in this phase"
        
        return True, ""
    
    def validate_creature_spawn(self, species: str, can_fly: bool) -> tuple[bool, str]:
        """Gatekeeper: Can this creature exist right now?"""
        if not self._current_state:
            return False, "Authority not initialized"
        
        rules = self._current_state.active_rules.fauna_rules
        
        if species in rules.forbidden_species:
            return False, f"Species {species} forbidden in phase {self._current_state.sky_phase.name}"
        
        if rules.allowed_species and species not in rules.allowed_species:
            return False, f"Species {species} not in allowed set"
        
        if can_fly and not rules.flight_permitted:
            return False, "Flight not permitted in this phase"
        
        return True, ""
    
    def validate_harvest(self, resource: str) -> tuple[bool, str]:
        """Gatekeeper: Can this resource be harvested right now?"""
        if not self._current_state:
            return False, "Authority not initialized"
        
        rules = self._current_state.active_rules.flora_rules
        
        if resource in rules.forbidden_resources:
            return False, f"Resource {resource} forbidden in phase {self._current_state.sky_phase.name}"
        
        if resource not in rules.harvestable_resources:
            return False, f"Resource {resource} not harvestable in this phase"
        
        return True, ""
    
    def get_current_state(self) -> EnvironmentState:
        """Read-only access to current state"""
        if not self._current_state:
            raise RuntimeError("Authority not initialized")
        return self._current_state
    
    def get_temperature_at_height(self, height_meters: float) -> float:
        """Query temperature at specific height"""
        if not self._current_state:
            raise RuntimeError("Authority not initialized")
        return self._current_state.active_rules.temperature_gradient.get_temp_at_height(height_meters)
    
    def subscribe_to_changes(self, callback: Callable[[EnvironmentState], None]) -> None:
        """Register callback for state changes"""
        self._state_change_callbacks.append(callback)
    
    def _notify_state_change(self) -> None:
        """Notify all subscribers of state change"""
        if self._current_state:
            for callback in self._state_change_callbacks:
                callback(self._current_state)
    
    def _checkpoint_to_phase(self, checkpoint_id: str) -> SkyPhase:
        """Map narrative checkpoint to sky phase"""
        # TODO: Load from narrative mapping
        # For now, hardcoded examples
        mapping = {
            "prologue": SkyPhase.WHITE,
            "act1_start": SkyPhase.YELLOW,
            "act1_climax": SkyPhase.PURPLE,
            "final_battle": SkyPhase.DEEP_CRIMSON
        }
        return mapping.get(checkpoint_id, SkyPhase.WHITE)
    
    def _determine_lightning_phase(self, sky_phase: SkyPhase) -> LightningPhase:
        """Map sky phase to lightning behavior mode"""
        if sky_phase in {SkyPhase.WHITE, SkyPhase.YELLOW}:
            return LightningPhase.PREDICTABLE
        elif sky_phase in {SkyPhase.PURPLE, SkyPhase.GREEN, SkyPhase.RED, SkyPhase.BLUE}:
            return LightningPhase.SEMI_RANDOM
        elif sky_phase in {SkyPhase.DEEP_CRIMSON, SkyPhase.BLACK}:
            return LightningPhase.EVENT_TRIGGERED
        return LightningPhase.DORMANT
    
    def _is_valid_transition(self, from_phase: SkyPhase, to_phase: SkyPhase) -> bool:
        """Validate phase transition is narratively legal"""
        # TODO: Load transition graph from narrative rules
        # For now, allow all transitions (trust checkpoint system)
        return True


# Example integration patterns for other systems

class VFXSystem:
    """Example: How visual effects system queries authority"""
    
    def __init__(self, authority: EnvironmentalAuthority):
        self.authority = authority
        authority.subscribe_to_changes(self._on_environment_change)
    
    def _on_environment_change(self, state: EnvironmentState) -> None:
        """React to phase changes"""
        print(f"VFX: Switching to {state.sky_phase.name} palette")
        # Update sky shader parameters
        # Load allowed color palettes
        # Never invent effects outside allowed set
    
    def spawn_lightning_effect(self, color: LightningColor, position: tuple) -> bool:
        """Request permission before spawning"""
        allowed, reason = self.authority.validate_lightning_strike(color, position)
        if not allowed:
            print(f"VFX: Cannot spawn lightning - {reason}")
            return False
        
        # Spawn the effect
        print(f"VFX: Spawning {color.name} lightning at {position}")
        return True


class GameplaySystem:
    """Example: How gameplay queries authority"""
    
    def __init__(self, authority: EnvironmentalAuthority):
        self.authority = authority
    
    def attempt_harvest(self, resource: str) -> bool:
        """Check if harvest is legal in current phase"""
        allowed, reason = self.authority.validate_harvest(resource)
        if not allowed:
            print(f"Gameplay: Harvest blocked - {reason}")
            return False
        
        print(f"Gameplay: Harvested {resource}")
        return True
    
    def get_aggression_modifier(self) -> float:
        """Query current fauna aggression level"""
        state = self.authority.get_current_state()
        return state.active_rules.fauna_rules.aggression_modifier


if __name__ == "__main__":
    # Example usage
    authority = EnvironmentalAuthority()
    authority.initialize("prologue", game_time=0.0)
    
    # Other systems connect
    vfx = VFXSystem(authority)
    gameplay = GameplaySystem(authority)
    
    # Systems query authority
    state = authority.get_current_state()
    print(f"Current phase: {state.sky_phase.name}")
    print(f"Lightning mode: {state.lightning_phase.name}")
    print(f"Allowed lightning colors: {[c.name for c in state.active_rules.allowed_lightning_colors]}")
    
    # Test validation
    vfx.spawn_lightning_effect(LightningColor.YELLOW, (100.0, 50.0, 0.0))  # OK
    vfx.spawn_lightning_effect(LightningColor.PURPLE, (100.0, 50.0, 0.0))  # BLOCKED
    
    gameplay.attempt_harvest("ice_wheat")  # OK
    gameplay.attempt_harvest("tropical_fruit")  # BLOCKED
    
    # Narrative progression
    print("\n--- Narrative advances to Act 1 climax ---")
    authority.advance_checkpoint("act1_climax", game_time=3600.0)
