# Copyright (c) 2025 ByteDance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from pathlib import Path

LOCAL_STORAGE_PATH = Path.home() / ".trae-agent"
