# Utils/models
Refactor the list of models into a more robust and developer-friendly format.
