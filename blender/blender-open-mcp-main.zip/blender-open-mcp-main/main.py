from blender_open_mcp.server import main as server_main

if __name__ == "__main__":
    main()