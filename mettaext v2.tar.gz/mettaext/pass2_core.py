#!/usr/bin/env python3
"""
pass2_core.py

CORE Metta extraction (Pass 2) for EngAIn:

- Speaker inference
- Pronoun resolution (actor)
- Emotion detection
- Action classification
- Thought attribution

Input:  Pass 1 file (tagged text), e.g. out_pass1_03_Fist_contact.txt
Output: Pass 2 metta,        e.g. out_pass2_out_pass1_03_Fist_contact.metta
"""

import sys
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple


# ---------- Data Model ----------

@dataclass
class Segment:
    tag_line_no: int          # physical line number with the {type:...}
    text_line_no: int         # same as tag_line_no for 1-line format, or next line for 2-line
    type: str                 # narration / dialogue / internal_monologue / blank / scene_header / header
    speaker: Optional[str]    # explicit speaker from pass1 or None
    text: str                 # the content (after tag or on following line)


# ---------- Patterns & Dictionaries ----------

TYPE_RE = re.compile(r'^\{type:([^,}]+)(?:,\s*speaker:([^}]+))?\}')

SPEECH_VERBS = (
    "said", "asked", "replied", "whispered", "muttered", "shouted",
    "called", "yelled", "answered", "continued", "countered", "observed",
    "added", "explained", "insisted", "remarked", "noted"
)

THOUGHT_VERBS = (
    "thought", "wondered", "doubted", "considered", "realized", "knew",
    "feared", "hoped", "decided", "resolved", "suspected"
)

# Base emotion keywords (explicit, not guessed)
EMOTION_KEYWORDS = {
    "trembled": "fear",
    "shivered": "fear",
    "terror": "fear",
    "afraid": "fear",
    "panic": "fear",
    "fear": "fear",

    "angry": "anger",
    "rage": "anger",
    "furious": "anger",

    "smiled": "contentment",
    "grinned": "contentment",

    "laughed": "joy",

    "wept": "sadness",
    "sobbed": "sadness",
    "cried": "sadness",

    "relief": "relief",
    "hope": "hope",
    "hopeful": "hope",

    "determination": "determination",
    "determined": "determination",

    # Added for your chapters
    "wonder": "wonder",
    "triumph": "triumph",
    "trepidation": "anxiety",
    "anticipation": "anticipation",
    "gratitude": "gratitude",
}

# Action keywords – verb/phrase → label
ACTION_KEYWORDS = {
    # multi-word / specific first
    "fell back": "retreat",
    "vrill-manipulation": "vrill_manipulation",
    "manipulated vrill": "vrill_manipulation",
    "kneeling": "submission",
    "kneel": "submission",
    "withdrew": "retreat",
    "retreated": "retreat",
    "stepped back": "retreat",
    "stepped forward": "advance",
    "moved closer": "advance",

    # generic
    "attacked": "attack",
    "attack": "attack",
    "charged": "advance",
    "lunged": "advance",
    "advanced": "advance",

    "cast": "cast_spell",
    "channelled": "cast_spell",
    "channeled": "cast_spell",

    "struck": "attack",
    "fired": "attack",

    "spoke": "speak",
    "whispered": "speak",
    "shouted": "speak",
    "called": "speak",

    # creation / shaping
    "create": "creation",
    "created": "creation",
    "shaping": "shaping",
}

PRONOUNS = ("he", "she", "they", "him", "her", "them", "his", "hers", "their", "theirs")


def is_capitalized_word(token: str) -> bool:
    return token and token[0].isupper() and token.isalpha()


# ---------- Parsing Pass 1 into Segments ----------

def load_segments(path: str) -> List[Segment]:
    """
    Parse a pass1 file into Segment objects.

    Supports BOTH:
      1) One-line format:
         {type:narration, speaker:none} The sun set...
      2) Two-line format:
         {type:narration}
         The sun set...
    """
    segments: List[Segment] = []
    with open(path, "r", encoding="utf-8") as f:
        lines = [line.rstrip("\n") for line in f]

    total = len(lines)
    line_idx = 0  # 0-based index into `lines`

    while line_idx < total:
        line_no = line_idx + 1
        raw = lines[line_idx]
        m = TYPE_RE.match(raw.strip())
        if not m:
            line_idx += 1
            continue

        seg_type = m.group(1).strip()
        speaker = m.group(2).strip() if m.group(2) else None

        # Default values
        text = ""
        text_line_no = line_no

        # Check for 1-line inline text AFTER the closing brace
        rest = raw[m.end():].strip()
        if rest:
            # One-line segment: tag and text share the same line
            text = rest
            text_line_no = line_no
            line_idx += 1
        else:
            # Two-line segment style: next line is the content (if any)
            if line_idx + 1 < total:
                next_raw = lines[line_idx + 1]
                # Only treat as content if it is not another tag line
                if not TYPE_RE.match(next_raw.strip()):
                    text = next_raw
                    text_line_no = line_no + 1
                    line_idx += 2
                else:
                    # No explicit content line
                    text = ""
                    text_line_no = line_no
                    line_idx += 1
            else:
                line_idx += 1

        segments.append(
            Segment(
                tag_line_no=line_no,
                text_line_no=text_line_no,
                type=seg_type,
                speaker=speaker,
                text=text,
            )
        )

    return segments


# ---------- Inference Passes ----------

def infer_speakers(segments: List[Segment]) -> List[Tuple[int, str, float]]:
    """
    For DIALOGUE segments with unknown speaker, try to infer speaker
    from inline patterns on this line or adjacent narration.

    Returns list of (line_no, speaker, confidence).
    """
    results = []

    # "Quote," Name said ...
    inline_pattern = re.compile(
        r'^"[^"]*"\s*,\s*(?P<name>[A-Z][A-Za-z0-9_-]*)\s+(?:' + "|".join(SPEECH_VERBS) + r')\b'
    )
    # Name said ...
    name_first_pattern = re.compile(
        r'^(?P<name>[A-Z][A-Za-z0-9_-]*)\s+(?:' + "|".join(SPEECH_VERBS) + r')\b'
    )
    # "Show them," came the faint impression through Senareth's Prime connection
    prime_impression_pattern = re.compile(
        r"through\s+(?P<name>[A-Z][A-Za-z0-9_-]*)'s\s+Prime", re.IGNORECASE
    )

    for idx, seg in enumerate(segments):
        if seg.type != "dialogue":
            continue
        if seg.speaker and seg.speaker.lower() != "unknown":
            continue  # speaker already explicit

        text = seg.text.strip()

        # (1) Check inline "Quote," Name said...
        m = inline_pattern.match(text)
        if m:
            name = m.group("name")
            results.append((seg.text_line_no, name, 1.0))
            continue

        # (2) If same-line narration: Name said...
        m2 = name_first_pattern.match(text)
        if m2:
            name = m2.group("name")
            results.append((seg.text_line_no, name, 1.0))
            continue

        # (3) Look at prev/next narration for "Name said..."
        found = False
        for offset in (-1, 1):
            j = idx + offset
            if j < 0 or j >= len(segments):
                continue
            nseg = segments[j]
            if nseg.type != "narration":
                continue
            stripped = nseg.text.strip()
            m3 = name_first_pattern.match(stripped)
            if m3:
                name = m3.group("name")
                results.append((seg.text_line_no, name, 0.95))
                found = True
                break

            # (4) Special: "came the faint impression through Senareth's Prime connection"
            m4 = prime_impression_pattern.search(stripped)
            if m4:
                name = m4.group("name")
                results.append((seg.text_line_no, name, 0.9))
                found = True
                break

        # if not found, we leave speaker unknown
    return results


def infer_pronoun_actors(segments: List[Segment]) -> List[Tuple[int, str, float]]:
    """
    Simple pronoun resolution:
    - track last explicit character (dialogue speakers, name-first narration)
    - when a narration/internal_monologue line starts with a pronoun, attach it.
    """
    results = []
    last_char: Optional[str] = None

    name_first_pattern = re.compile(r'^(?P<name>[A-Z][A-Za-z0-9_-]*)\b')

    for seg in segments:
        # Update last_char for explicit speakers
        if seg.type == "dialogue" and seg.speaker and seg.speaker.lower() != "unknown":
            last_char = seg.speaker
            continue

        if seg.type in ("narration", "internal_monologue"):
            stripped = seg.text.lstrip()

            # update last_char if line starts with a Name
            m = name_first_pattern.match(stripped)
            if m:
                last_char = m.group("name")

            tokens = stripped.split()
            if not tokens:
                continue
            first = tokens[0].lower().strip(".,!?;:")
            if first in PRONOUNS and last_char:
                results.append((seg.text_line_no, last_char, 0.8))

    return results


def infer_emotions(segments: List[Segment]) -> List[Tuple[int, Optional[str], str, float]]:
    """
    Explicit keyword-based emotion detection.

    Attach to last_char when possible, else actor=None (unknown).
    """
    results = []
    last_char: Optional[str] = None

    name_first_pattern = re.compile(r'^(?P<name>[A-Z][A-Za-z0-9_-]*)\b')

    for seg in segments:
        if seg.type == "dialogue" and seg.speaker and seg.speaker.lower() != "unknown":
            last_char = seg.speaker

        if seg.type in ("narration", "internal_monologue"):
            stripped = seg.text.lstrip()
            m = name_first_pattern.match(stripped)
            if m:
                last_char = m.group("name")

            lower = stripped.lower()
            for kw, emo in EMOTION_KEYWORDS.items():
                if kw in lower:
                    results.append((seg.text_line_no, last_char, emo, 0.9))
                    break

    return results


def infer_actions(segments: List[Segment]) -> List[Tuple[int, str, float]]:
    """
    Keyword-based action label detection.
    """
    results = []
    for seg in segments:
        if seg.type not in ("narration", "dialogue", "internal_monologue"):
            continue
        lower = seg.text.lower()
        hit = None
        for phrase, label in ACTION_KEYWORDS.items():
            if phrase in lower:
                hit = label
                break
        if hit:
            results.append((seg.text_line_no, hit, 0.9))
    return results


def infer_thoughts(segments: List[Segment]) -> List[Tuple[int, Optional[str], float]]:
    """
    Detect thought attribution from patterns like:
    - "Name thought ..."
    - "He wondered if ..."
    - any asterisk-wrapped internal phrase *like this*
    in narration or internal_monologue.

    Returns: (line_no, actor or None, confidence).
    """
    results = []

    # Name ... thought / wondered / etc. (anywhere in line)
    name_thought_pattern = re.compile(
        r'(?P<name>[A-Z][A-Za-z0-9_-]*)\s+(?P<verb>' + "|".join(THOUGHT_VERBS) + r')\b',
        re.IGNORECASE,
    )
    # Pronoun ... thought / wondered / etc. (start of line or later)
    pronoun_thought_pattern = re.compile(
        r'\b(?P<pronoun>He|She|They)\s+(?P<verb>' + "|".join(THOUGHT_VERBS) + r')\b',
        re.IGNORECASE,
    )
    # *internal monologue* blocks
    asterisk_thought_pattern = re.compile(r'\*([^*]+)\*')

    last_char: Optional[str] = None

    for seg in segments:
        # Keep track of last explicit speaker
        if seg.type == "dialogue" and seg.speaker and seg.speaker.lower() != "unknown":
            last_char = seg.speaker
            continue

        if seg.type not in ("narration", "internal_monologue"):
            continue

        stripped = seg.text.lstrip()

        # If internal_monologue already has a concrete speaker, treat as thought
        if seg.type == "internal_monologue" and seg.speaker and seg.speaker.lower() != "unknown":
            results.append((seg.text_line_no, seg.speaker, 1.0))
            last_char = seg.speaker  # update context
            # still continue scanning – there might be extra patterns
            # (no 'continue' here)

        # Name ... thought / wondered / etc
        m_name = name_thought_pattern.search(stripped)
        if m_name:
            name = m_name.group("name")
            results.append((seg.text_line_no, name, 1.0))
            last_char = name
            # don't 'continue': still allow asterisk-based detection below

        # Pronoun ... thought / wondered / etc.
        m_pron = pronoun_thought_pattern.search(stripped)
        if m_pron and last_char:
            results.append((seg.text_line_no, last_char, 0.85))

        # Asterisk-wrapped text: *Why are they afraid of us?*
        if asterisk_thought_pattern.search(stripped):
            # if we already know a Name or last_char, assign, else unknown
            actor = last_char
            conf = 0.8 if actor else 0.6
            results.append((seg.text_line_no, actor, conf))

    return results


# ---------- Writing Pass 2 Metta ----------

def write_metta(
    out_path: str,
    speakers,
    actors,
    emotions,
    actions,
    thoughts,
) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("; Pass 2 CORE inferences (speaker, actor, emotion, action, thought)\n\n")

        if speakers:
            f.write("; ---- Speaker Inference ----\n")
            for line_no, name, conf in speakers:
                f.write(f"(speaker line:{line_no} {name} :confidence {conf:.2f})\n")
            f.write("\n")

        if actors:
            f.write("; ---- Pronoun → Actor ----\n")
            for line_no, name, conf in actors:
                f.write(f"(actor line:{line_no} {name} :confidence {conf:.2f})\n")
            f.write("\n")

        if emotions:
            f.write("; ---- Emotions ----\n")
            for line_no, actor, emo, conf in emotions:
                actor_atom = actor if actor is not None else "unknown"
                f.write(f"(emotion line:{line_no} {actor_atom} {emo} :confidence {conf:.2f})\n")
            f.write("\n")

        if actions:
            f.write("; ---- Actions ----\n")
            for line_no, label, conf in actions:
                f.write(f"(action line:{line_no} {label} :confidence {conf:.2f})\n")
            f.write("\n")

        if thoughts:
            f.write("; ---- Thoughts ----\n")
            for line_no, actor, conf in thoughts:
                actor_atom = actor if actor is not None else "unknown"
                f.write(f"(thought line:{line_no} {actor_atom} :confidence {conf:.2f})\n")
            f.write("\n")


# ---------- CLI ----------

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 pass2_core.py <pass1_input.txt> [pass2_output.metta]")
        sys.exit(1)

    input_path = sys.argv[1]

    if len(sys.argv) >= 3:
        output_path = sys.argv[2]
    else:
        base = os.path.splitext(os.path.basename(input_path))[0]
        output_path = f"out_pass2_{base}.metta"

    if not os.path.exists(input_path):
        print(f"Input file not found: {input_path}")
        sys.exit(1)

    segments = load_segments(input_path)

    speakers = infer_speakers(segments)
    actors = infer_pronoun_actors(segments)
    emotions = infer_emotions(segments)
    actions = infer_actions(segments)
    thoughts = infer_thoughts(segments)

    write_metta(output_path, speakers, actors, emotions, actions, thoughts)

    print(f"[PASS-2 CORE] Inference complete → {output_path}")


if __name__ == "__main__":
    main()
