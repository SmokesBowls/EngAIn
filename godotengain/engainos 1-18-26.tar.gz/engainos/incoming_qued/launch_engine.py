#!/usr/bin/env python3
"""
launch_engine.py - EngAIn Engine Bootstrap (Authoritative)

This is the ONLY blessed runtime entrypoint.
No bypassing. No mocking. No clever tricks.

If this fails, fix the engine - do not work around it.

Authority: core/launch_engine.py
Status: CANONICAL ENTRYPOINT
"""

import sys
import os
from pathlib import Path
import threading
import time

# ============================================================================
# PHASE 1: PATH AUTHORITY (No CWD assumptions)
# ============================================================================

# Lock to this file's location
SCRIPT_PATH = Path(__file__).resolve()
CORE = SCRIPT_PATH.parent
ROOT = CORE.parent

# Required directories
TOOLS = ROOT / "tools"
GODOT = ROOT / "godot"
ASSETS = ROOT / "assets"
TESTS = ROOT / "tests"

print("=" * 70)
print("ENGAIN ENGINE BOOTSTRAP")
print("=" * 70)
print(f"Authority: {SCRIPT_PATH}")
print(f"Root:      {ROOT}")
print(f"Core:      {CORE}")
print(f"Tools:     {TOOLS}")
print(f"Godot:     {GODOT}")
print("=" * 70)
print()

# ============================================================================
# PHASE 2: ENGINE INVARIANTS (Learning gate)
# ============================================================================

def assert_invariant(condition: bool, message: str):
    """Assert engine invariant - fail hard if false"""
    if not condition:
        print(f"❌ ENGINE INVARIANT VIOLATION:", file=sys.stderr)
        print(f"   {message}", file=sys.stderr)
        print(f"   Fix the engine before proceeding.", file=sys.stderr)
        sys.exit(1)

def check_no_import_violation(source_dir: Path, forbidden_import: str) -> bool:
    """Check that source_dir does not import forbidden module"""
    if not source_dir.exists():
        return True
    
    for py_file in source_dir.rglob("*.py"):
        try:
            with open(py_file, 'r') as f:
                content = f.read()
                if f"import {forbidden_import}" in content or f"from {forbidden_import}" in content:
                    return False
        except:
            pass
    return True

print("[PHASE 2] Checking engine invariants...")
print()

# Invariant 1: Required core files exist
print("  [1/7] Core law files...")
assert_invariant(
    (CORE / "mesh_intake.py").exists(),
    "mesh_intake.py missing - this is the HARD GATE"
)
assert_invariant(
    (CORE / "mesh_manifest.py").exists(),
    "mesh_manifest.py missing - manifest system required"
)
assert_invariant(
    (CORE / "scene_server.py").exists(),
    "scene_server.py missing - HTTP server required"
)
assert_invariant(
    (CORE / "godot_adapter.py").exists(),
    "godot_adapter.py missing - Godot bridge required"
)
print("  ✓ All core law files present")

# Invariant 2: Required directories exist
print("  [2/7] Directory structure...")
assert_invariant(
    TOOLS.exists() and TOOLS.is_dir(),
    f"tools/ directory missing at {TOOLS}"
)
assert_invariant(
    (TOOLS / "trixel").exists(),
    "tools/trixel/ missing - creator tools required"
)
assert_invariant(
    GODOT.exists() and GODOT.is_dir(),
    f"godot/ directory missing at {GODOT}"
)
print("  ✓ Required directories present")

# Invariant 3: Boundary enforcement (CRITICAL)
print("  [3/7] Import boundaries (CRITICAL)...")
assert_invariant(
    check_no_import_violation(CORE, "godot"),
    "VIOLATION: core/ imports from godot (not allowed)"
)
assert_invariant(
    check_no_import_violation(CORE, "tools"),
    "VIOLATION: core/ imports from tools/ (not allowed)"
)
assert_invariant(
    check_no_import_violation(TOOLS, "godot"),
    "VIOLATION: tools/ imports from godot (not allowed)"
)
print("  ✓ Boundaries clean: core ← tools ← godot")

# Invariant 4: Python version
print("  [4/7] Python version...")
py_version = sys.version_info
assert_invariant(
    py_version >= (3, 10),
    f"Python 3.10+ required, got {py_version.major}.{py_version.minor}"
)
print(f"  ✓ Python {py_version.major}.{py_version.minor}.{py_version.micro}")

# Invariant 5: Core imports are importable
print("  [5/7] Core module imports...")
sys.path.insert(0, str(CORE))
try:
    from scene_server import start_scene_server
    from godot_adapter import GodotAdapter
    print("  ✓ Core modules importable")
except ImportError as e:
    assert_invariant(False, f"Core module import failed: {e}")

# Invariant 6: Assets structure
print("  [6/7] Asset structure...")
if not ASSETS.exists():
    ASSETS.mkdir(parents=True)
    print("  ✓ Created assets/ directory")
if not (ASSETS / "trixels").exists():
    (ASSETS / "trixels").mkdir(parents=True)
    print("  ✓ Created assets/trixels/ directory")
print("  ✓ Asset structure ready")

# Invariant 7: No test pollution
print("  [7/7] Test isolation...")
# Tests can mock runtime, but runtime must never depend on tests
assert_invariant(
    not any("import tests" in str(p) or "from tests" in str(p) 
            for p in CORE.rglob("*.py")),
    "VIOLATION: core/ imports from tests/ (not allowed)"
)
print("  ✓ Tests isolated from runtime")

print()
print("✓ All engine invariants verified")
print()

# ============================================================================
# PHASE 3: SUBSYSTEM STARTUP (Explicit, ordered, validated)
# ============================================================================

print("[PHASE 3] Starting subsystems...")
print()

# Subsystem 1: Scene HTTP Server (background)
scene_server_thread = None
scene_server_port = 8765

def run_scene_server():
    """Run scene server in background thread"""
    try:
        print(f"  [SceneServer] Starting on port {scene_server_port}...", file=sys.stderr)
        start_scene_server(port=scene_server_port)
    except Exception as e:
        print(f"  [SceneServer] ERROR: {e}", file=sys.stderr)
        sys.exit(1)

print(f"  [1/2] Scene HTTP server (port {scene_server_port})...")
scene_server_thread = threading.Thread(target=run_scene_server, daemon=True)
scene_server_thread.start()

# Give server time to bind port
time.sleep(0.5)

if scene_server_thread.is_alive():
    print(f"  ✓ Scene server running on port {scene_server_port}")
else:
    assert_invariant(False, "Scene server failed to start")

print()

# Subsystem 2: Godot Adapter (foreground)
print("  [2/2] Godot adapter (stdin/stdout bridge)...")

adapter = GodotAdapter()

# Optional: Load scene from command line
scene_path = None
if len(sys.argv) > 1:
    scene_path = Path(sys.argv[1])
    if not scene_path.exists():
        print(f"  ⚠ Scene file not found: {scene_path}", file=sys.stderr)
        scene_path = None
    else:
        print(f"  ✓ Loading scene: {scene_path}")

# Default scene (if no arg provided)
if scene_path is None:
    default_scene = ROOT / "game_scenes" / "test_scene.json"
    if default_scene.exists():
        scene_path = default_scene
        print(f"  ✓ Loading default scene: {scene_path}")
    else:
        print(f"  ⚠ No scene specified, starting empty")

if scene_path:
    try:
        adapter.initialize(scene_path)
        print(f"  ✓ Scene initialized")
    except Exception as e:
        print(f"  ✗ Scene initialization failed: {e}", file=sys.stderr)
        print(f"  Continuing without scene...", file=sys.stderr)

print()
print("=" * 70)
print("ENGINE READY")
print("=" * 70)
print()
print("Subsystems:")
print(f"  • Scene server:   http://localhost:{scene_server_port}/")
print(f"  • Godot adapter:  stdin/stdout bridge active")
print(f"  • Scene loaded:   {scene_path or 'none'}")
print()
print("To stop: Ctrl+C")
print("=" * 70)
print()

# ============================================================================
# PHASE 4: RUNTIME LOOP (Godot adapter runs here)
# ============================================================================

try:
    adapter.run_loop()
except KeyboardInterrupt:
    print("\n" + "=" * 70)
    print("ENGINE SHUTDOWN")
    print("=" * 70)
    sys.exit(0)
except Exception as e:
    print(f"\n❌ ENGINE RUNTIME ERROR:", file=sys.stderr)
    print(f"   {e}", file=sys.stderr)
    print("=" * 70, file=sys.stderr)
    sys.exit(1)
