#!/usr/bin/env python3
"""
godot_bridge_test.py - Python Bridge for Godot

Called by EngAInBridge.gd to get Entity3D data as JSON.

Usage:
    python3 godot_bridge_test.py --scene chapter1_opening

Output:
    JSON with entity RenderPlan data
"""

import sys
import os
import json
import argparse

# Add core to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from zon_to_entities import zon_scene_to_entities
from spatial_skin_system import build_render_plan


# ================================================================
# TEST SCENES (Fake ZON data for testing)
# ================================================================

TEST_SCENES = {
    "chapter1_opening": {
        "scene_id": "chapter1_opening",
        "entities": [
            {
                "type": "guard",
                "position": [10.0, 0.0, 5.0],
                "rotation": [0.0, 1.57, 0.0],
                "id": "guard_001",
                "tags": ["patrol", "hostile"]
            },
            {
                "type": "guard",
                "position": [15.0, 0.0, 5.0],
                "rotation": [0.0, -1.57, 0.0],
                "id": "guard_002",
                "tags": ["patrol", "hostile"]
            },
            {
                "type": "merchant",
                "position": [5.0, 0.0, 10.0],
                "id": "merchant_001",
                "tags": ["friendly", "vendor"]
            },
            {
                "type": "door",
                "position": [0.0, 0.0, 15.0],
                "scale": [2.0, 3.0, 0.2],
                "id": "door_001",
                "tags": ["locked"]
            },
            {
                "type": "barrel",
                "position": [3.0, 0.0, 8.0],
                "id": "barrel_001"
            },
            {
                "type": "chest",
                "position": [12.0, 0.0, 12.0],
                "id": "chest_001",
                "tags": ["loot"]
            }
        ]
    },
    
    "test_minimal": {
        "scene_id": "test_minimal",
        "entities": [
            {
                "type": "player",
                "position": [0.0, 0.0, 0.0],
                "id": "player"
            },
            {
                "type": "guard",
                "position": [5.0, 0.0, 5.0],
                "id": "guard_001"
            }
        ]
    }
}


# ================================================================
# CONVERSION
# ================================================================

def render_plan_to_json(render_plan) -> dict:
    """
    Convert RenderPlan to JSON-serializable dict.
    
    Args:
        render_plan: RenderPlan instance
    
    Returns:
        Dictionary with all data Godot needs
    """
    return {
        "placeholder_mesh": render_plan.mesh_type,
        "transform": render_plan.transform.to_dict(),
        "color": {
            "r": render_plan.color.r,
            "g": render_plan.color.g,
            "b": render_plan.color.b
        },
        "skin_3d_id": render_plan.skin_3d_id,
        "skin_2d_id": render_plan.skin_2d_id,
        "zw_concept": render_plan.logic_tags.get("zw_concept", "unknown"),
        "ap_profile": render_plan.logic_tags.get("ap_profile", "generic"),
        "entity_id": render_plan.logic_tags.get("entity_id", "unknown"),
        "tags": render_plan.logic_tags.get("tags", []),
        "kernel_bindings": render_plan.logic_tags.get("kernel_bindings", {})
    }


def get_scene_data(scene_id: str) -> dict:
    """
    Get scene data as JSON for Godot.
    
    Args:
        scene_id: Scene identifier
    
    Returns:
        Dictionary with scene data
    """
    # Get ZON scene (from test data)
    if scene_id not in TEST_SCENES:
        return {
            "error": f"Scene not found: {scene_id}",
            "entities": []
        }
    
    zon_scene = TEST_SCENES[scene_id]
    
    # Convert to Entity3D
    entities = zon_scene_to_entities(zon_scene, auto_bind_skins=False)
    
    # Build RenderPlans
    render_plans = [build_render_plan(entity) for entity in entities]
    
    # Convert to JSON
    json_entities = [render_plan_to_json(plan) for plan in render_plans]
    
    return {
        "scene_id": scene_id,
        "entity_count": len(json_entities),
        "entities": json_entities
    }


# ================================================================
# CLI ENTRY POINT
# ================================================================

def main():
    parser = argparse.ArgumentParser(description="EngAIn → Godot Bridge")
    parser.add_argument("--scene", required=True, help="Scene ID to load")
    
    args = parser.parse_args()
    
    # Get scene data
    scene_data = get_scene_data(args.scene)
    
    # Output as JSON
    print(json.dumps(scene_data, indent=2))


if __name__ == "__main__":
    main()
