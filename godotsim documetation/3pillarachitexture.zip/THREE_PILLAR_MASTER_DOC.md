# THE THREE-PILLAR TEMPORAL ARCHITECTURE
## EngAIn, MV-CAR, and the Presentation Engine

**Document Version:** 1.0.0  
**Date:** December 24, 2025  
**Status:** Phase 1 (Two-Pillar Validation) In Progress  
**Philosophy:** Narrative first, code last. Temporal truth beats generative guessing.

---

## 🎯 EXECUTIVE SUMMARY

This document describes a **three-pillar temporal operating system** for games that treats logic, audio, and visuals as **separate, deterministic renderers** of the same underlying narrative truth.

**The Three Pillars:**
1. **EngAIn** (Truth Engine) - What is true in the world?
2. **MV-CAR** (Sound Engine) - What does it sound like?
3. **Presentation Engine** (Show Engine) - How is it shown?

**All three:**
- Share the same **immutable narrative canon**
- Use **deterministic temporal fabrics**
- Apply **rule-based rendering** (no guessing)
- Output to **Godot as unified scheduler**

**Current Status:**
- ✅ Pillar 1 (EngAIn): Operational (7 subsystems)
- ⏳ Pillar 2 (MV-CAR): Integration in progress
- 🔒 Pillar 3 (Presentation): Reserved for Phase 3

---

## 🏛️ THE ARCHITECTURAL PATTERN

### **Discovery, Not Design**

This architecture wasn't planned. It was **discovered through consistency.**

By building EngAIn (game logic) and MV-CAR (music/voice) using the same principles, an inevitable pattern emerged:

```
Canon (Immutable Narrative)
        ↓
Temporal Fabric (Deterministic Timeline)
        ↓
Rule Renderers (Table-Driven Logic)
        ↓
Output (Inspectable, Reproducible)
        ↓
Godot Runtime (Unified Scheduler)
```

**This pattern appears THREE times:**
1. EngAIn: Narrative → ZON4D → MR Kernels → Snapshots → Godot
2. MV-CAR: Canon → Spine → Symbolic Music → timeline.json → Godot
3. Presentation: Canon → Visual Spine → Camera Rules → staging.json → Godot

**Same shape. Same discipline. Same refusal to guess.**

---

## 🔥 PILLAR 1: ENGAIN (TRUTH ENGINE)

### **Question Answered:** "What is TRUE right now?"

**Purpose:** Authoritative game state and logic

**Components:**

#### **1. Canon**
- Immutable narrative source (Zork ZIL code, story beats)
- Semantic extraction via ZW blocks (semantic compression)
- Hash-locked to prevent untracked changes

#### **2. Temporal Fabric: ZON4D**
- 4D memory fabric (space + time)
- Tracks entity state, events, history
- Deterministic tick-based progression
- Absolute temporal authority (owns game clock)

#### **3. Rule Renderers: MR Kernels**
- Pure functional map-reduce kernels
- Snapshot-in → snapshot-out
- Zero side effects, fully deterministic
- Examples: spatial3d_mr.py, combat3d_mr.py

#### **4. Adapter Layers**
- AP (Anti-Python) constraint validation
- Deep contract integration with ZON4D
- Delta queuing and rollback support

#### **5. Output Format**
- ZONB snapshots (binary)
- ZONJ intermediate (JSON)
- Deltas for incremental updates
- HTTP protocol (NGAT-RT v1.0)

**Subsystems (7 Operational):**
1. Spatial3D - Physics, collision, movement
2. Perception3D - Sensing, awareness, FOV
3. Navigation3D - Pathfinding, waypoints
4. Behavior3D - AI decision-making
5. Combat3D - Damage, health, death, wounds
6. Inventory3D - Items, weight, capacity, fumble
7. Dialogue3D - Conversation, reputation, branches

**Status:** ✅ **PRODUCTION READY**
- Python runtime operational
- Godot client integrated
- All subsystems tested
- 2/3 architectural critique fixes complete

---

## 🎵 PILLAR 2: MV-CAR (SOUND ENGINE)

### **Question Answered:** "What does this SOUND like?"

**Purpose:** Deterministic music and voice generation

**Components:**

#### **1. Canon**
- Hash-locked lyrics and story timeline
- Immutable source of narrative truth
- Same philosophical foundation as EngAIn

#### **2. Temporal Fabric: Spine + timeline.json**
- Chronology-locked narrative spine
- Segments with arc roles (emergence, conflict, resolution)
- Absolute time references (abs_start_sec, abs_time_sec)
- TTS map (voice line placements)

#### **3. Rule Renderers: Symbolic Music**
- Tension → harmony tables
- Valence → chord progression
- Density → rhythm patterns
- Arc role → orchestration (instruments, articulation)
- Deterministic MIDI generation

#### **4. Outputs**
- **timeline.json** - THE TRUTH (temporal schedule)
- **MIDI files** - Symbolic performance data
- **Intent sheets** - Human-readable constraints
- **TTS map** - Voice line index and timing
- **Audio renders** - WAV files for Godot

#### **5. Properties**
- Seed-based determinism (same inputs → same music)
- Inspectable (intent sheets survive re-renders)
- No generative guessing (all from tables/rules)
- Engine-agnostic (MIDI, timeline.json portable)

**Status:** ✅ **STRUCTURALLY COMPLETE**
- All core components built
- Godot integration layer created (AudioTimeline.gd)
- Wiring to EngAIn pending (one-line integration)
- Ready for Phase 1 validation

---

## 📹 PILLAR 3: PRESENTATION ENGINE (SHOW ENGINE)

### **Question Answered:** "How is this moment SHOWN?"

**Purpose:** Deterministic visual staging and cinematic orchestration

**Status:** 🔒 **RESERVED (Not Yet Built)**

**Projected Components:**

#### **1. Canon**
- Same immutable narrative as Pillars 1-2
- Visual beats extracted from story structure
- Camera moments aligned to narrative spine

#### **2. Temporal Fabric: Visual Spine**
- Staging.json format (parallel to timeline.json)
- Camera beats, shot boundaries, reveal moments
- Aligned to same temporal grid as MV-CAR
- Absolute time references (same clock)

#### **3. Rule Renderers: Camera/Staging Kernels**
- Camera distance = f(arc_role, tension)
- FOV = base_fov + (tension * ramp_factor)
- Lighting temperature = f(valence)
- UI reveal timing = timeline events
- Cut boundaries = bar/beat aligned
- No shot changes unless declared

#### **4. Output Format: staging.json**
```json
{
  "shots": [
    {
      "shot_id": "shot_001",
      "abs_start_sec": 0.0,
      "duration_sec": 4.0,
      "camera": {
        "distance": 5.0,
        "fov": 70,
        "target": "player"
      },
      "lighting": {
        "temperature": 5600,
        "intensity": 0.8
      }
    }
  ],
  "ui_reveals": [...],
  "fx_triggers": [...]
}
```

#### **5. Godot Integration**
- Cinematic orchestration layer (parallel to AudioTimeline)
- Consumes staging.json
- Updates camera, lighting, UI based on game time
- Same listening pattern (never owns time)

**Why It's Not Optional:**
- Without it: Visuals **react** instead of **know**
- With it: All three pillars speak same temporal language
- Result: **Coherence instead of coincidence**

**When to Build:**
- ⏳ After Phase 1 (two-pillar validation)
- ⏳ After Phase 2 (production polish)
- 🎯 Phase 3: Architectural convergence

---

## 🔗 THE UNIFIED RUNTIME: GODOT

### **Godot is Not "The Engine"**

**Godot is the Runtime Executor.**

It consumes three deterministic timelines and schedules their outputs.

**Role:**
- ✅ Scheduler (executes on time)
- ❌ Interpreter (does NOT decide what to do)

**Inputs:**

| Source | Format | Protocol | Transport |
|--------|--------|----------|-----------|
| EngAIn | ZONB snapshots | NGAT-RT v1.0 | HTTP polling |
| MV-CAR | timeline.json | Absolute time | File load |
| Presentation | staging.json | TBD | TBD |

**Temporal Model:**
- **One Clock:** EngAIn ZWRuntime owns `game_time_sec`
- **All Listen:** MV-CAR and Presentation never advance time
- **Synchronization:** All outputs keyed to `game_time_sec`

**Result:**
- Music plays when `game_time >= abs_start_sec`
- Voice triggers when `game_time >= abs_time_sec`
- Camera cuts when `game_time >= shot_start_sec`

**No polling. No guessing. No desync.**

---

## 📅 THREE-PHASE ROADMAP

### **PHASE 1: Two-Pillar Validation** (IN PROGRESS)

**Goals:**
- Complete MV-CAR → Godot integration
- Validate temporal synchronization
- Prove audio schedules to game time correctly

**Deliverables:**
- ✅ AudioTimeline.gd (MV-CAR scheduler)
- ⏳ ZWRuntime integration (one-line wire)
- ⏳ Test scene validation
- ⏳ Working game with synced audio

**Success Criteria:**
- Music segments play on schedule
- Voice lines trigger at correct times
- Audio syncs to game events (combat, dialogue)
- Deterministic playback (reload → same audio)

**Estimated Duration:** Days to 1 week

---

### **PHASE 2: Production Polish** (PLANNED)

**Goals:**
- Polish existing systems to shippable quality
- Add critical missing subsystem (Quest3D)
- Production hardening (contracts, validation)

**Deliverables:**
- Fix #3: Health bar smoothing (visual polish)
- Quest3D subsystem operational
- Save/load audio state
- Production-ready two-pillar system

**Success Criteria:**
- Game is playable end-to-end
- Visual/audio quality polished
- No critical bugs
- Two-pillar architecture proven

**Estimated Duration:** 2-4 weeks

---

### **PHASE 3: Architectural Convergence** (RESERVED)

**Goals:**
- Design third pillar (Presentation Engine)
- Build visual spine and staging rules
- Wire to unified temporal fabric
- Achieve three-pillar convergence

**Deliverables:**
- Presentation engine specification
- staging.json format design
- Camera/light/FX rule renderers
- Godot cinematic orchestration layer
- Complete three-pillar architecture

**Success Criteria:**
- Truth, Sound, Show all synchronized
- Camera cuts aligned to music beats
- UI reveals aligned to story moments
- Complete temporal coherence

**Estimated Duration:** Weeks to months

---

## 🧬 ARCHITECTURAL DNA

### **Core Principles (Never Compromise)**

1. **Narrative First**
   - Canon is immutable source of truth
   - All rendering flows from narrative
   - Code is mechanical, not creative

2. **Temporal Determinism**
   - Same inputs → same outputs (always)
   - Seed-based randomness (reproducible)
   - One clock (EngAIn owns time)

3. **Rule-Based Rendering**
   - Tables, not heuristics
   - Math, not models
   - Inspectable, not opaque

4. **Separation of Concerns**
   - Truth (EngAIn) doesn't know Sound (MV-CAR)
   - Sound doesn't know Show (Presentation)
   - All communicate through temporal fabric

5. **No Generative Guessing**
   - MV-CAR doesn't invent notes
   - Presentation doesn't invent shots
   - EngAIn doesn't invent story beats

### **Anti-Patterns (Always Avoid)**

- ❌ Event-driven audio (use state-driven)
- ❌ Multiple time sources (one clock only)
- ❌ Polling loops (signal-driven)
- ❌ SaaS dependencies (local control)
- ❌ Abstraction leakage (clean boundaries)
- ❌ Duplicate validation (single source)

---

## 🎓 LESSONS LEARNED

### **From EngAIn Development:**
1. Pure functional MR kernels enable determinism
2. Three-layer pattern (kernel → adapter → integration) scales
3. AP constraint rules prevent invalid states
4. ZON4D temporal fabric tracks complex interactions
5. Fix #2: Protocol-kernel naming boundaries critical

### **From MV-CAR Development:**
1. Chronology-locked spine enables deterministic music
2. Tension/valence/density maps cleanly to music parameters
3. Intent sheets make AI output human-readable
4. Absolute time references eliminate sync issues
5. Hash-locked canon prevents drift

### **From Two-Pillar Integration:**
1. Single clock eliminates sync complexity
2. Listening pattern (never own time) scales to N pillars
3. Same philosophical foundation → same architectural shape
4. Godot as scheduler (not interpreter) is correct model
5. Third pillar is inevitable, not optional

---

## 📊 SUCCESS METRICS

### **Two-Pillar Validation:**
- **Metric:** Audio plays on schedule
- **Test:** Trigger combat → music switches
- **Pass:** Audio within 100ms of schedule

### **Three-Pillar Convergence:**
- **Metric:** All systems synchronized
- **Test:** Music beat → camera cut
- **Pass:** All three pillars aligned to clock

### **Determinism:**
- **Metric:** Same inputs → same outputs
- **Test:** Reload save → exact resume
- **Pass:** Bit-perfect reproduction

---

## 🚀 FOR FUTURE CHATS

### **How to Pick This Up:**

1. **Read This File First**
   - Understand three-pillar architecture
   - Grasp philosophical foundation
   - Know current phase status

2. **Check THREE_PILLAR_ARCHITECTURE.json**
   - Machine-readable spec
   - Current implementation status
   - Key file locations

3. **Review Phase Roadmap**
   - Know what's complete
   - Understand what's next
   - See blocking dependencies

4. **Key Context:**
   - EngAIn operational (7 subsystems)
   - MV-CAR structurally complete
   - Integration layer built (AudioTimeline.gd)
   - Third pillar reserved (not built)

### **What You're Inheriting:**

**A working two-pillar temporal operating system** that proves:
- Deterministic game logic works (EngAIn)
- Deterministic music works (MV-CAR)
- Same pattern applies to both
- Third pillar follows same shape

**Your job (future chat):**
- Complete MV-CAR integration (Phase 1)
- Polish to production quality (Phase 2)
- Design third pillar when ready (Phase 3)

### **Don't Break:**
- Single clock temporal model
- Canon immutability discipline
- Rule-based rendering purity
- Clean separation of concerns

### **Remember:**
> "Two systems coexist. Three systems converge."

Build two first. Validate they work. **Then** add the third.

---

## 💬 CLOSING THOUGHTS

This isn't hype. It's architectural reality discovered through consistency.

**What makes this special:**
- Not planned - discovered
- Not clever - inevitable
- Not flexible - disciplined
- Not generative - deterministic

**Why it matters:**
- AI can read it (intent artifacts)
- Humans can trust it (inspectable)
- Time can't break it (deterministic)
- Scale won't kill it (clean separation)

**The third pillar completes the pattern.**

But it's not needed to ship.
It's needed to **converge**.

Two pillars make a game.
Three pillars make a **system**.

---

**End of Master Documentation**

*For technical details, see THREE_PILLAR_ARCHITECTURE.json*  
*For integration guide, see INTEGRATION_COMPLETE.md*  
*For current status, check phase roadmap in JSON manifest*
