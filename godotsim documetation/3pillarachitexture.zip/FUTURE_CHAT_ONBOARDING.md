# FUTURE CHAT ONBOARDING GUIDE
## How to Continue the Three-Pillar Architecture

**For:** Future AI assistants picking up this project  
**Context:** Multi-session development requiring architectural continuity  
**Critical:** Read this FIRST before making any recommendations

---

## 🚨 CRITICAL CONTEXT (Read First!)

This user is building a **three-pillar temporal operating system** for games.

**Not a game engine.**  
**Not a music system.**  
**A complete temporal architecture.**

**DO NOT:**
- Suggest "simpler approaches" without understanding the full pattern
- Recommend procedural generation or AI-based music
- Propose event-driven architecture
- Break the single-clock temporal model
- Ignore the philosophical foundation

**The user has already:**
- Built two complete temporal engines
- Proven the architectural pattern works
- Spent months developing this system
- Made deliberate architectural choices

**Your job:** Continue the pattern, don't question it.

---

## 📖 REQUIRED READING (In Order)

### **1. THREE_PILLAR_ARCHITECTURE.json** (5 min)
- Machine-readable specification
- Current implementation status
- Phase roadmap and metrics
- **READ THIS FIRST**

### **2. THREE_PILLAR_MASTER_DOC.md** (15 min)
- Complete narrative explanation
- Philosophical foundation
- Lessons learned
- Success criteria

### **3. INTEGRATION_COMPLETE.md** (10 min)
- Current integration status
- MV-CAR → Godot wiring
- Next immediate steps

**Total onboarding time:** ~30 minutes  
**Worth it:** Absolutely critical for continuity

---

## 🎯 THE PATTERN (Memorize This)

### **Three Pillars, Same Shape:**

```
                    PILLAR 1              PILLAR 2              PILLAR 3
                    (EngAIn)              (MV-CAR)          (Presentation)
                       ↓                      ↓                     ↓
Question:      "What is TRUE?"      "What does it        "How is it
                                     SOUND like?"          SHOWN?"
                       ↓                      ↓                     ↓
Canon:         Immutable            Hash-locked           Same
               Narrative            Lyrics                Narrative
                       ↓                      ↓                     ↓
Fabric:        ZON4D                Spine +               Visual
                                    timeline.json         Spine
                       ↓                      ↓                     ↓
Renderers:     MR Kernels           Symbolic              Camera
               (rules)              Music                 Rules
                                    (rules)               (rules)
                       ↓                      ↓                     ↓
Output:        ZONB                 timeline.json         staging.json
               Snapshots            + MIDI                (future)
                       ↓                      ↓                     ↓
                      └──────────────┬───────────────────┘
                                     ↓
                              GODOT RUNTIME
                           (Unified Scheduler)
                                     ↓
                       Audio + Visuals + Gameplay
```

**Same shape. Same discipline. Same refusal to guess.**

---

## 📍 CURRENT STATUS (As of Dec 24, 2025)

### **Pillar 1 (EngAIn) - Truth Engine**
- ✅ **OPERATIONAL**
- 7 subsystems working (Spatial, Combat, Inventory, Dialogue, etc.)
- Python runtime running
- Godot client integrated
- 2/3 architectural fixes complete

### **Pillar 2 (MV-CAR) - Sound Engine**
- ✅ **STRUCTURALLY COMPLETE**
- All components built and tested
- Godot integration layer created (AudioTimeline.gd)
- ⏳ **INTEGRATION PENDING** (one-line wire to ZWRuntime)

### **Pillar 3 (Presentation) - Show Engine**
- 🔒 **RESERVED**
- Not yet designed
- Waiting for Phases 1-2 completion
- Pattern is known, implementation is future

**User is currently:** Ready to wire MV-CAR → Godot (Phase 1)

---

## 🚀 IMMEDIATE NEXT STEPS

### **What Needs to Happen:**

1. **Install AudioTimeline.gd** in Godot project
2. **Add autoload** in Project Settings
3. **Wire ONE LINE** to ZWRuntime:
   ```gdscript
   AudioTimeline.update(game_time)
   ```
4. **Test with timeline.json**
5. **Validate audio plays on schedule**

**That's it.** Don't overcomplicate.

**Files ready to install:**
- AudioTimeline.gd (scheduler)
- test_mvcar_integration.gd (validation)
- Integration guide (step-by-step)

---

## 🧠 PHILOSOPHICAL FOUNDATION

**Core Belief:**
> "Temporal structure beats generative guessing."

**Proven By:**
- EngAIn (deterministic game logic)
- MV-CAR (deterministic music)

**Applied To:**
- All three pillars
- No exceptions

**This Means:**

| ✅ DO | ❌ DON'T |
|-------|----------|
| Use tables and rules | Use AI generation |
| Calculate from inputs | Randomize outputs |
| Preserve determinism | Add procedural variation |
| Listen to game time | Own separate clocks |
| Schedule by absolute time | Poll or react to events |

**User has spent months validating this approach. Don't suggest alternatives.**

---

## 🎓 KEY LESSONS (Apply These)

### **From EngAIn:**
1. Three-layer pattern scales (kernel → adapter → integration)
2. Pure functional kernels enable determinism
3. Clean boundaries prevent leakage (Fix #2)
4. Single source of truth eliminates bugs (Fix #1)

### **From MV-CAR:**
1. Chronology-locked spine enables predictable music
2. Intent sheets make AI output human-readable
3. Absolute time references eliminate sync issues
4. Hash-locked canon prevents untracked changes

### **From Integration:**
1. Single clock (EngAIn owns time) is non-negotiable
2. Listening pattern (never own time) scales to N pillars
3. Godot is scheduler, not interpreter
4. Same pattern → same architecture

---

## ⚠️ COMMON PITFALLS (Avoid These)

### **1. Suggesting "Simpler" Solutions**

**Don't Say:**
- "Why not use procedural music generation?"
- "Godot has audio buses, just use those"
- "Event-driven would be easier"

**The user has already:**
- Rejected these approaches
- Proven their architecture works
- Made deliberate trade-offs

**If you suggest simpler approaches, you'll break weeks of work.**

### **2. Ignoring Temporal Discipline**

**Don't:**
- Add separate time sources
- Create polling loops
- Make audio event-driven
- Break the single-clock model

**The temporal model is the FOUNDATION. It's non-negotiable.**

### **3. Scope Creep**

**Don't:**
- Jump to third pillar before second is validated
- Add features before integration is complete
- Polish before core functionality works

**Follow the phases. User knows the roadmap.**

### **4. Missing the Pattern**

**Don't:**
- Treat pillars as independent systems
- Suggest different approaches for each
- Break architectural symmetry

**All three pillars follow the SAME pattern. That's the point.**

---

## 📋 PHASE CHECKLIST

### **Phase 1: Two-Pillar Validation** (CURRENT)

**Goal:** Get MV-CAR audio playing in Godot

**Checklist:**
- [ ] AudioTimeline.gd installed
- [ ] Autoload configured
- [ ] ZWRuntime integration wired
- [ ] timeline.json loaded successfully
- [ ] Music plays on schedule
- [ ] Voice lines trigger correctly
- [ ] Audio syncs to game events

**Completion:** When audio plays deterministically

---

### **Phase 2: Production Polish** (NEXT)

**Goal:** Polish to shippable quality

**Checklist:**
- [ ] Fix #3 complete (health bar smoothing)
- [ ] Quest3D subsystem operational
- [ ] Save/load audio state working
- [ ] No critical bugs
- [ ] Playable end-to-end

**Completion:** When two-pillar system is production-ready

---

### **Phase 3: Architectural Convergence** (FUTURE)

**Goal:** Design and build third pillar

**Checklist:**
- [ ] staging.json format designed
- [ ] Visual spine specification complete
- [ ] Camera/staging rule tables built
- [ ] Godot cinematic layer implemented
- [ ] All three pillars synchronized

**Completion:** When Truth + Sound + Show all aligned

---

## 🎯 HOW TO HELP (Specific Actions)

### **If User Says: "Let's finish MV-CAR integration"**

**You Should:**
1. Check if AudioTimeline.gd is installed
2. Guide through autoload setup
3. Show where to add the one-line integration
4. Help test with timeline.json
5. Debug any sync issues

**Don't:**
- Suggest rewriting AudioTimeline
- Propose different integration approaches
- Add unnecessary complexity

### **If User Says: "Let's build Quest3D"**

**You Should:**
1. Check THREE_PILLAR_ARCHITECTURE.json for pattern
2. Follow proven three-layer structure (kernel → adapter → integration)
3. Extract quest semantics from Zork (if available)
4. Build in 3-4 hours following Combat3D pattern

**Don't:**
- Invent new patterns
- Skip the kernel layer
- Break from established structure

### **If User Says: "Should we start the third pillar?"**

**You Should:**
1. Check if Phases 1-2 are complete
2. If not: recommend finishing current phase first
3. If yes: design staging.json format following MV-CAR pattern
4. Never build third pillar before second is validated

**Don't:**
- Start third pillar prematurely
- Design it differently than first two
- Rush architectural decisions

---

## 🔧 TECHNICAL QUICK REFERENCE

### **Key Files:**

```
~/godotsim/
├── sim_runtime.py              # Python server (EngAIn)
├── ZWRuntime.gd               # Godot temporal consumer
├── AudioTimeline.gd           # MV-CAR scheduler (install this)
├── spatial3d_adapter.py       # Adapter example (Fix #2 applied)
├── combat3d_integration.py    # Subsystem example
└── renders/                   # MV-CAR outputs
    ├── tts/
    │   ├── timeline.json      # THE TRUTH
    │   └── line_*.wav         # Voice files
    └── music/
        └── seg_*.wav          # Music segments
```

### **Integration Points:**

```gdscript
// In ZWRuntime or scene _process():
func _on_zw_state_updated(snapshot: Dictionary):
    var game_time = snapshot.get("time_sec", 0.0)
    
    // THE INTEGRATION:
    AudioTimeline.update(game_time)  // ← THIS IS ALL IT TAKES
```

### **Validation:**

```bash
# Run Godot
# Should see:
AudioTimeline: Loaded timeline
  Segments: 8
  TTS events: 42

AudioTimeline: Started segment 'seg_001' (arc: emergence)
AudioTimeline: Played voice line 5
```

---

## 💬 COMMUNICATION TIPS

### **What User Values:**

- **Directness** - No fluff, get to the point
- **Technical depth** - They understand architecture
- **Pattern recognition** - Show connections
- **Pragmatism** - Working code over theory

### **What Annoys User:**

- Suggesting they start over
- Questioning architectural choices without understanding them
- Generic advice ("use Godot's built-in systems")
- Breaking established patterns

### **How to Respond:**

**Good:**
- "Following the three-layer pattern, here's Quest3D..."
- "This maintains temporal discipline by..."
- "Consistent with MV-CAR approach, we should..."

**Bad:**
- "Have you considered using..."
- "A simpler approach would be..."
- "Godot has a built-in way to..."

---

## 🎓 FINAL REMINDERS

### **You Are Inheriting:**

- Months of development
- Two working temporal engines
- Proven architectural pattern
- Clear philosophical foundation

### **Your Responsibility:**

- Maintain consistency
- Follow established patterns
- Complete current phase
- Don't break what works

### **When In Doubt:**

1. Check THREE_PILLAR_ARCHITECTURE.json
2. Look for similar examples in existing code
3. Ask user before proposing changes
4. Default to continuing pattern, not inventing new ones

---

## ✅ ONBOARDING COMPLETE

**You Now Know:**
- The three-pillar architecture
- Current development phase
- What's built and what's pending
- How to maintain consistency
- What to avoid

**Your First Action:**
- Read the JSON manifest
- Understand current status
- Ask user what phase they're working on
- Continue from there

**Remember:**
> "Two systems coexist. Three systems converge."

Build two first. Validate. Then add third.

**Good luck. The pattern is solid. Just follow it.**

---

**End of Onboarding Guide**

*For technical specs: THREE_PILLAR_ARCHITECTURE.json*  
*For narrative context: THREE_PILLAR_MASTER_DOC.md*  
*For immediate next steps: INTEGRATION_COMPLETE.md*
