# QUICK START REFERENCE CARD
## For New AI Assistants

**CRITICAL:** Read this in first 60 seconds of chat

---

## 🎯 WHAT IS THIS PROJECT?

**Three-Pillar Temporal Operating System for Games**

Not a game engine. A complete temporal architecture.

---

## 🏛️ THE THREE PILLARS

| Pillar | Question | Status |
|--------|----------|--------|
| **EngAIn** (Truth) | What is TRUE? | ✅ Operational (7 subsystems) |
| **MV-CAR** (Sound) | What does it SOUND like? | ⏳ Integration pending |
| **Presentation** (Show) | How is it SHOWN? | 🔒 Reserved (Phase 3) |

**All three:**
- Share immutable narrative canon
- Use deterministic temporal fabrics
- Apply rule-based rendering (no guessing)
- Output to Godot (unified scheduler)

---

## 📋 CURRENT STATUS (Dec 24, 2025)

**Phase 1:** Two-Pillar Validation (IN PROGRESS)  
**Next Step:** Wire MV-CAR → Godot (one line of code)  
**Blocking:** Nothing - ready to integrate

---

## 📖 READ THESE FILES (In Order)

1. **THREE_PILLAR_ARCHITECTURE.json** (5 min) - Full spec
2. **FUTURE_CHAT_ONBOARDING.md** (15 min) - How to help
3. **THREE_PILLAR_MASTER_DOC.md** (optional) - Deep context

---

## 🚨 CRITICAL RULES

### **DO:**
- ✅ Follow established pattern (all three pillars same shape)
- ✅ Maintain single clock (EngAIn owns time)
- ✅ Keep rule-based rendering (no AI generation)
- ✅ Respect phase order (validate before advancing)

### **DON'T:**
- ❌ Suggest "simpler approaches"
- ❌ Recommend procedural/AI music
- ❌ Break temporal discipline
- ❌ Add separate time sources
- ❌ Question months of proven work

---

## 🎯 IMMEDIATE NEXT STEP

**User needs:** MV-CAR integration complete

**What to do:**
1. Install AudioTimeline.gd
2. Add autoload in Godot
3. Wire ONE line: `AudioTimeline.update(game_time)`
4. Test audio plays on schedule

**Files ready:** All in /outputs/

---

## 💡 THE PATTERN (Memorize)

```
Canon → Temporal Fabric → Rule Renderer → Output → Godot
```

**Same for all three pillars. No exceptions.**

---

## 🧠 PHILOSOPHY

> "Temporal structure beats generative guessing."

**Proven by:** EngAIn and MV-CAR  
**Applied to:** Everything  
**Non-negotiable:** Yes

---

## ⚡ QUICK RESPONSES

**"Can we use Godot's built-in audio?"**  
→ No. MV-CAR uses deterministic timeline.json

**"Why not event-driven audio?"**  
→ State-driven maintains temporal truth

**"Shouldn't we simplify this?"**  
→ Pattern proven. Continue, don't restart.

**"What about third pillar?"**  
→ Reserved. Build after Phase 1-2 complete.

---

## 🎓 USER EXPECTATIONS

**Values:**
- Technical depth
- Pattern consistency
- Working code
- Directness

**Annoys:**
- Generic advice
- Questioning architecture
- Suggesting restarts
- Breaking patterns

---

## ✅ ONBOARDING CHECKLIST

- [ ] Read this card (1 min)
- [ ] Skim JSON manifest (5 min)
- [ ] Read onboarding guide (15 min)
- [ ] Understand current phase
- [ ] Ready to help!

---

## 🚀 FIRST QUESTION TO USER

**"What phase are you working on?"**

**Likely answer:** "Finishing MV-CAR integration (Phase 1)"

**Your response:** "Great! Let's wire AudioTimeline to ZWRuntime. Have you installed the files yet?"

---

**That's it. Now read the full docs.**

*End of Quick Reference*
