# ZW/ZON/AP QUICK REFERENCE CARD
## The 5-Minute Implementation Guide

**Status:** STONE CARVED  
**Use Case:** Quick lookup during subsystem migration

---

## THE THREE PILLARS (One Sentence Each)

**ZW:** Events with @id/@when/@where that invoke AP rules  
**AP:** Declarative rules that explain WHY they fail  
**ZON:** Immutable snapshots reconstructible from events

---

## THE 5 INVARIANTS (Checklist)

- [ ] **INVARIANT 1:** System REFUSES events without @when
- [ ] **INVARIANT 2:** State = initial_snapshot + event_log (replay works)
- [ ] **INVARIANT 3:** Failures include reason + actual_value
- [ ] **INVARIANT 4:** Kernel is pure (same input = same output)
- [ ] **INVARIANT 5:** Invalid operations rejected with explanation

---

## FILE STRUCTURE (Copy This)

```
subsystem_kernel.gd          # Pure functions, no state
subsystem_adapter.gd         # Event log, current state
subsystem_proof_kernel.gd    # 5-invariant test
subsystem_proof.tscn         # Test scene
```

---

## EVENT STRUCTURE (Template)

```gdscript
{
    "@id": "subsystem/evt_12345",
    "@when": "epoch:T+42.5",
    "@where": "realm/zone/location",
    "rule_id": "action_name",
    "payload": {"actor": "player"}
}
```

---

## AP RULE STRUCTURE (Template)

```gdscript
{
    "id": "action_name",
    "requires": [
        {"stat": "entity.stat >= value"},
        {"flag": "entity.flag"}
    ],
    "effects": [
        {"change": "entity.stat += value"}
    ],
    "conflicts": [
        {"flag": "entity.blocking_flag"}
    ]
}
```

---

## KERNEL TEMPLATE (Copy-Paste)

```gdscript
static func operation_kernel(
    snapshot_in: Dictionary,
    event: ZWEvent,
    rule: APRule
) -> Dictionary:
    var snapshot_out = _deep_copy(snapshot_in)
    
    for effect in rule.effects:
        _apply_effect(effect, snapshot_out)
    
    return snapshot_out

static func _deep_copy(data):
    return data.duplicate(true)
```

---

## ADAPTER TEMPLATE (Copy-Paste)

```gdscript
class_name SubsystemAdapter
extends Node

const Kernel = preload("res://subsystem_kernel.gd")

var _current_snapshot: Dictionary = {}
var _event_log: Array = []
var _initial_snapshot: Dictionary = {}
var _rules: Dictionary = {}

func _ready():
    _current_snapshot = Kernel.create_initial_snapshot()
    _initial_snapshot = _deep_copy(_current_snapshot)
    _register_rules()

func execute_action(rule_id: String, context: Dictionary) -> Dictionary:
    var event = ZWEvent.new({
        "@id": "subsystem/evt_%d" % Time.get_ticks_msec(),
        "@when": "%s:T+%.2f" % [_epoch, _time],
        "@where": context.get("location", "realm/unknown"),
        "rule_id": rule_id,
        "payload": context
    })
    
    var rule = _rules[rule_id]
    var check = rule.check_requires(_current_snapshot)
    if not check["success"]:
        return {"success": false, "reason": check["reason"]}
    
    var new_snapshot = Kernel.operation_kernel(_current_snapshot, event, rule)
    
    _event_log.append({
        "@id": event.id,
        "@when": event.when,
        "@where": event.where,
        "rule_id": event.rule_id,
        "payload": event.payload
    })
    
    _current_snapshot = new_snapshot
    return {"success": true}
```

---

## PROOF TEST TEMPLATE (Copy-Paste)

```gdscript
static func run_proof_test() -> Dictionary:
    var adapter = SubsystemProofAdapter.new(initial_state, "test")
    var results = {"invariants_passed": 0, "tests": []}
    
    # TEST 1: Refuse without @when
    var test1 = adapter.execute_action("rule", {"location": ""})
    results["tests"].append({
        "name": "INVARIANT 1: Temporal identity",
        "passed": not test1["success"]
    })
    if not test1["success"]: results["invariants_passed"] += 1
    
    # TEST 2: Valid execution
    var test2 = adapter.execute_action("rule", valid_context)
    results["tests"].append({
        "name": "INVARIANT 2: Valid execution",
        "passed": test2["success"]
    })
    if test2["success"]: results["invariants_passed"] += 1
    
    # CRITICAL: Save state before Test 3 hack
    var state_before_hack = adapter.current_snapshot.duplicate(true)
    
    # TEST 3: Interrogability
    adapter.current_snapshot["stat"] = invalid_value
    var test3 = adapter.execute_action("rule", context)
    results["tests"].append({
        "name": "INVARIANT 3: Interrogable",
        "passed": not test3["success"] and test3.has("reason")
    })
    if not test3["success"] and test3.has("reason"): results["invariants_passed"] += 1
    
    # TEST 4: Query mode
    var query = adapter.query_why_failed("rule")
    var test4_pass = "keyword" in query.to_lower()
    results["tests"].append({
        "name": "INVARIANT 4: Queryable",
        "passed": test4_pass
    })
    if test4_pass: results["invariants_passed"] += 1
    
    # TEST 5: Replay (use state_before_hack!)
    var replay = adapter.test_replay(state_before_hack)
    results["tests"].append({
        "name": "INVARIANT 5: Replay",
        "passed": replay["success"]
    })
    if replay["success"]: results["invariants_passed"] += 1
    
    return results
```

---

## CRITICAL GOTCHAS (Don't Forget)

1. **Defensive Normalization:**
   ```gdscript
   # DON'T: requires = rule_def.get("requires", [])
   # DO:
   requires = [] as Array[Dictionary]
   for req in rule_def.get("requires", []):
       if req is Dictionary: requires.append(req)
   ```

2. **Test 5 Hack:**
   ```gdscript
   # BEFORE Test 3:
   var state_before_hack = adapter.current_snapshot.duplicate(true)
   
   # IN Test 5:
   var replay = adapter.test_replay(state_before_hack)  # NOT current_snapshot
   ```

3. **Class Name Conflicts:**
   ```gdscript
   # If you have subsystem_validator.gd with class_name SubsystemValidator
   # Then proof kernel must use different name:
   class SubsystemProofValidator  # Note: no class_name keyword
   ```

4. **Event Logging:**
   ```gdscript
   # MUST happen AFTER kernel succeeds:
   _event_log.append({"@id": ..., "@when": ..., "@where": ..., "rule_id": ..., "payload": ...})
   ```

5. **Kernel Purity:**
   ```gdscript
   # ALWAYS copy input
   var snapshot_out = _deep_copy(snapshot_in)
   # NEVER mutate snapshot_in
   # NO randomness, NO time calls, NO I/O
   ```

---

## COMMON ERRORS & FIXES

**Error:** "There is already a variable named X"  
**Fix:** Check for duplicate sed applications, restore clean file

**Error:** "Class X hides a global script class"  
**Fix:** Rename inner class or remove class_name from one file

**Error:** "Preload file does not exist"  
**Fix:** Check file path, clear .godot cache

**Error:** Test 5 (Replay) fails  
**Fix:** Compare against state_before_hack, not current_snapshot

**Error:** Test 3 always passes  
**Fix:** Verify you're actually modifying state to invalid value

---

## VALIDATION CHECKLIST

Before claiming 5/5:
- [ ] Run proof test from terminal: `godot --path . subsystem_proof.tscn`
- [ ] Verify output shows "Invariants Passed: 5 / 5"
- [ ] Check all test details (not just summary)
- [ ] Test with 10+ events in event log
- [ ] Verify replay works multiple times
- [ ] Test edge cases (boundaries, missing fields)
- [ ] Clear .godot and retest

---

## NEXT SUBSYSTEM WORKFLOW

1. Copy this card
2. Copy Combat3D or Faction3D proof kernel
3. Search/replace "Combat" → "YourSubsystem"
4. Define your snapshot structure
5. Define your AP rules
6. Implement kernel functions
7. Run proof test
8. Debug until 5/5
9. Integrate with runtime
10. Move to next subsystem

**Expected Time:** 2-4 hours per subsystem

---

## REFERENCE IMPLEMENTATIONS

**Combat3D:** `~/godotsim/test/combat_proof_kernel.gd` (5/5 ✅)  
**Faction3D:** `~/godotsim/faction3d_proof_kernel.gd` (5/5 ✅)

**Full Documentation:** `ZW_ZON_AP_PATTERN_BIBLE.md`

---

**This card is STONE CARVED. Pattern proven on 2/2 subsystems.**
