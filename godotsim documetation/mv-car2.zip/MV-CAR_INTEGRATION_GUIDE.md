# MV-CAR → GODOT INTEGRATION GUIDE

**Integration Status:** Code complete, ready to install  
**Time Required:** 5 minutes  
**Files Needed:** AudioTimeline.gd, test_mvcar_integration.gd

---

## 🎯 WHAT THIS DOES

Connects MV-CAR (music/voice temporal engine) to Godot's runtime, allowing:
- ✅ Audio scheduled by game time (not wall time)
- ✅ Deterministic playback (same time = same audio)
- ✅ Save/load support (reset timeline state)
- ✅ Zero SaaS dependency (timeline.json is local)

---

## 📦 INSTALLATION (3 STEPS)

### **Step 1: Copy Files**

```bash
# Copy integration files to your Godot project
cp AudioTimeline.gd ~/godotsim/
cp test_mvcar_integration.gd ~/godotsim/
```

### **Step 2: Add Autoload**

1. Open Godot Editor
2. Go to: **Project → Project Settings → Autoload**
3. Add new autoload:
   - **Path:** `res://AudioTimeline.gd`
   - **Node Name:** `AudioTimeline`
   - **Enable:** ✅ Checked
4. Click "Add"
5. Close Project Settings

### **Step 3: Create Directory Structure**

```bash
cd ~/godotsim
mkdir -p renders/tts
mkdir -p renders/music
```

**Optional:** Copy MV-CAR outputs if you have them:
```bash
cp /path/to/mvcar/timeline.json renders/tts/
cp /path/to/mvcar/line_*.wav renders/tts/
cp /path/to/mvcar/seg_*.wav renders/music/
```

---

## ✅ VALIDATION TEST

### **Run Test Scene:**

1. Open Godot
2. Create new scene → Other Node → Node
3. Attach script: `test_mvcar_integration.gd`
4. Run scene (F5)

**Expected output:**
```
=== MV-CAR INTEGRATION TEST ===
Testing temporal synchronization...
✅ Timeline loaded successfully
Starting time simulation...
Game time: 0.00s
Game time: 1.02s
...
```

**If timeline.json missing:**
```
⚠️  Timeline not loaded (expected if timeline.json missing)
   Integration still valid, just no audio files
```

**This is fine!** Integration works, just no audio to play yet.

---

## 🔌 WIRE TO ZWRUNTIME

### **In your main game loop** (wherever you process ZWRuntime state):

**Add ONE line:**

```gdscript
# Example: In your _process() or state update function
func _process(delta):
    # Your existing ZWRuntime code...
    var game_state = poll_zwruntime()
    var game_time = game_state.get("time_sec", 0.0)
    
    # THIS IS THE INTEGRATION LINE:
    AudioTimeline.update(game_time)
    
    # Rest of your game logic...
```

**That's it.** AudioTimeline now receives authoritative time from EngAIn.

---

## 🎵 TIMELINE.JSON FORMAT

If you need to create a test timeline manually:

```json
{
  "voice_lines": [
    {
      "abs_time_sec": 5.0,
      "filename": "line_001.wav",
      "text": "Test voice line",
      "speaker": "narrator"
    }
  ],
  "music_segments": [
    {
      "abs_time_sec": 0.0,
      "filename": "seg_001.wav",
      "duration_sec": 30.0
    }
  ]
}
```

Place in `renders/tts/timeline.json`

---

## 🐛 TROUBLESHOOTING

### **"AudioTimeline autoload not found"**
- Check Project Settings → Autoload
- Verify path is `res://AudioTimeline.gd`
- Restart Godot editor

### **"Timeline not loaded"**
- Check `renders/tts/timeline.json` exists
- Verify JSON is valid
- Check console for parse errors

### **"Voice file not found"**
- Verify `.wav` files in `renders/tts/`
- Check filenames match timeline.json
- Ensure files are imported as AudioStreamWAV

### **Audio not playing**
- Verify `AudioTimeline.update()` is being called
- Check game time is advancing
- Verify trigger times in timeline.json
- Check Godot audio bus settings

---

## 📊 VALIDATION CHECKLIST

- [ ] AudioTimeline.gd copied to project
- [ ] Autoload configured in Project Settings
- [ ] Directory structure created
- [ ] Test scene runs without errors
- [ ] `AudioTimeline.update()` wired to game loop
- [ ] Timeline.json loads (or warning shown if missing)
- [ ] Audio plays at correct game times

---

## 🚀 NEXT STEPS

After validation:

1. **Generate MV-CAR outputs** if you haven't already
2. **Test with actual game content**
3. **Add stem support** (adaptive music layers)
4. **Implement save/load** (AudioTimeline.reset())
5. **Build Quest3D subsystem** (4th EngAIn subsystem)

---

## 💡 ARCHITECTURE NOTES

**Single Clock Discipline:**
- EngAIn owns time (game_time_sec)
- MV-CAR listens to time (AudioTimeline.update())
- Never advance time from audio side
- State-driven, not event-driven

**Determinism:**
- Same game time → same audio state
- Reproducible across runs
- Save/load support via reset()
- No race conditions (single authority)

**Separation of Concerns:**
- EngAIn: What is TRUE? (game logic)
- MV-CAR: What does it SOUND? (audio)
- Godot: Execute both (scheduler)

---

## ✅ SUCCESS CRITERIA

Integration is successful when:

1. ✅ AudioTimeline loads without errors
2. ✅ `update()` receives game time each frame
3. ✅ Audio triggers at correct times
4. ✅ Reset works (can restart timeline)
5. ✅ No audio glitches or timing drift

**When this works, Phase 1 is complete.**

---

**Questions? Check THREE_PILLAR_ARCHITECTURE.json for full system spec.**
