# FIXED: Spatial Kernel Signature Mismatch

## Problem
```
[SPATIAL ERROR] step_spatial3d() missing 1 required positional argument: 'dt'
```

## Root Cause
Runtime was calling spatial kernel with wrong signature:
```python
# WRONG
updated_state = step_spatial3d(spatial_state, dt)
```

But actual kernel signature is:
```python
def step_spatial3d(snapshot_in, deltas, dt, gravity=(0,-9.81,0)):
    ...
    return (snapshot_out, accepted_delta_ids, alerts)
```

**Missing:** deltas argument
**Wrong:** Return value handling (tuple of 3, not single dict)

## Fix Applied
```python
# CORRECT
snapshot_in = {"spatial3d": spatial_state}
snapshot_out, accepted, alerts = step_spatial3d(
    snapshot_in,
    [],  # Empty deltas for now
    dt
)
updated_spatial = snapshot_out.get("spatial3d", {})
```

## Quick Test
```bash
cd ~/godotsim
cp sim_runtime_with_slices.py sim_runtime.py
python3 sim_runtime.py
```

**Should see:**
- ✓ No more [SPATIAL ERROR]
- ✓ Behavior still fires deltas
- ✓ Entities update positions

## What Changed
1. Wrapped spatial_state in `{"spatial3d": ...}` format
2. Added empty `[]` for deltas argument
3. Unpacked return tuple: `snapshot_out, accepted, alerts`
4. Extracted entities from `snapshot_out["spatial3d"]`
5. Convert tuples to lists: `list(spatial_data["pos"])`

Both slice-protected path AND fallback path fixed.
