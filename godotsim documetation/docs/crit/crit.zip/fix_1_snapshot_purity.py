#!/usr/bin/env python3
"""
FIX 1: SNAPSHOT PURITY ENFORCER
Eliminates kernel name contamination in authoritative snapshots

PROBLEM: Internal kernel names (pos, vel) leak into wire protocol
SOLUTION: Strict translation boundaries with active guardrails

Changes:
1. SliceBuilder raises error on forbidden fields
2. create_entity_state uses ONLY protocol names
3. Kernel writeback purges leaked keys
"""

from typing import Dict, Any, List
import copy

# =============================================================================
# FORBIDDEN KERNEL FIELDS
# =============================================================================

FORBIDDEN_IN_SNAPSHOT = {
    'pos',  # Use 'position' instead
    'vel',  # Use 'velocity' instead
    # Add other kernel-internal names here
}

PROTOCOL_TRANSLATION = {
    'pos': 'position',
    'vel': 'velocity',
}

# =============================================================================
# GUARDRAIL: SliceBuilder with Active Rejection
# =============================================================================

class SliceError(Exception):
    """Raised when snapshot contains forbidden kernel fields"""
    pass


def build_entity_slice_v1(snapshot_entity: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build entity slice from snapshot with ACTIVE GUARDRAILS
    
    CRITICAL: Rejects snapshots containing kernel field names
    
    Args:
        snapshot_entity: Entity data from authoritative snapshot
        
    Returns:
        Clean slice for kernel consumption
        
    Raises:
        SliceError: If forbidden fields detected in snapshot
    """
    
    # GUARDRAIL: Check for contamination
    forbidden_found = FORBIDDEN_IN_SNAPSHOT & set(snapshot_entity.keys())
    
    if forbidden_found:
        raise SliceError(
            f"SNAPSHOT CONTAMINATION DETECTED! "
            f"Forbidden kernel fields in snapshot: {forbidden_found}. "
            f"Snapshot must use protocol names only: {PROTOCOL_TRANSLATION}"
        )
    
    # Extract protocol fields (clean snapshot)
    position = snapshot_entity.get('position', [0.0, 0.0, 0.0])
    velocity = snapshot_entity.get('velocity', [0.0, 0.0, 0.0])
    
    # Translate to kernel representation
    kernel_slice = {
        'id': snapshot_entity['id'],
        'pos': tuple(position),      # Translate: position → pos
        'vel': tuple(velocity),      # Translate: velocity → vel
        'radius': snapshot_entity.get('radius', 0.5),
        'solid': snapshot_entity.get('solid', True),
        'tags': snapshot_entity.get('tags', []),
    }
    
    return kernel_slice


# =============================================================================
# SOURCE INTEGRITY: Create Entity State (Clean Birth)
# =============================================================================

def create_entity_state(entity_id: str,
                       position: tuple,
                       velocity: tuple = (0.0, 0.0, 0.0),
                       radius: float = 0.5,
                       solid: bool = True,
                       tags: List[str] = None) -> Dict[str, Any]:
    """
    Create entity state using ONLY protocol names
    
    CRITICAL: Source of truth must be clean from birth
    NEVER use 'pos' or 'vel' here
    
    Args:
        entity_id: Unique entity identifier
        position: World position [x, y, z] - PROTOCOL NAME
        velocity: Movement velocity - PROTOCOL NAME
        radius: Collision radius
        solid: Collision enabled
        tags: Entity tags
        
    Returns:
        Clean entity state dict with protocol names
    """
    
    if tags is None:
        tags = []
    
    # STRICT: Only protocol names allowed
    return {
        'id': entity_id,
        'position': list(position),    # PROTOCOL NAME
        'velocity': list(velocity),    # PROTOCOL NAME
        'radius': radius,
        'solid': solid,
        'tags': tags,
    }


# =============================================================================
# DEFENSIVE CLEANUP: Kernel Writeback Purge
# =============================================================================

def write_kernel_output_to_snapshot(snapshot: Dict[str, Any],
                                   kernel_output: Dict[str, Any]) -> None:
    """
    Write kernel output to snapshot with MANDATORY CLEANUP
    
    Process:
    1. Translate kernel names → protocol names
    2. Write to snapshot
    3. PURGE any leaked kernel keys (defensive)
    
    Args:
        snapshot: Authoritative snapshot (modified in-place)
        kernel_output: MR kernel output with kernel field names
    """
    
    entities_snapshot = snapshot.setdefault('spatial3d', {}).setdefault('entities', {})
    entities_kernel = kernel_output.get('spatial3d', {}).get('entities', {})
    
    for entity_id, kernel_entity in entities_kernel.items():
        
        # Get or create snapshot entity
        if entity_id not in entities_snapshot:
            entities_snapshot[entity_id] = {'id': entity_id}
        
        snap_entity = entities_snapshot[entity_id]
        
        # STEP 1: Translate kernel → protocol (CORRECT names)
        if 'pos' in kernel_entity:
            snap_entity['position'] = list(kernel_entity['pos'])
        
        if 'vel' in kernel_entity:
            snap_entity['velocity'] = list(kernel_entity['vel'])
        
        # Copy other fields directly
        for key in ['radius', 'solid', 'tags']:
            if key in kernel_entity:
                snap_entity[key] = kernel_entity[key]
        
        # STEP 2: MANDATORY CLEANUP - Purge leaked kernel keys
        # This is defensive programming - catches accidental writes
        for forbidden_key in FORBIDDEN_IN_SNAPSHOT:
            snap_entity.pop(forbidden_key, None)  # Silent removal
    
    # Tiny overhead, massive safety guarantee


# =============================================================================
# VALIDATION: Snapshot Purity Checker
# =============================================================================

def validate_snapshot_purity(snapshot: Dict[str, Any]) -> List[str]:
    """
    Validate snapshot contains NO kernel field names
    
    Returns:
        List of violations (empty if pure)
    """
    violations = []
    
    entities = snapshot.get('spatial3d', {}).get('entities', {})
    
    for entity_id, entity_data in entities.items():
        forbidden_found = FORBIDDEN_IN_SNAPSHOT & set(entity_data.keys())
        
        if forbidden_found:
            violations.append(
                f"Entity '{entity_id}' has forbidden fields: {forbidden_found}"
            )
    
    return violations


def assert_snapshot_purity(snapshot: Dict[str, Any]) -> None:
    """
    Assert snapshot purity - FAIL HARD on contamination
    
    Raises:
        SliceError: If any contamination detected
    """
    violations = validate_snapshot_purity(snapshot)
    
    if violations:
        raise SliceError(
            "SNAPSHOT PURITY VIOLATION!\n" +
            "\n".join(violations) +
            f"\n\nForbidden fields: {FORBIDDEN_IN_SNAPSHOT}\n" +
            f"Use protocol names: {PROTOCOL_TRANSLATION}"
        )


# =============================================================================
# INTEGRATION EXAMPLE
# =============================================================================

if __name__ == "__main__":
    print("="*70)
    print("SNAPSHOT PURITY ENFORCER - DEMONSTRATION")
    print("="*70)
    
    # TEST 1: Clean entity creation
    print("\n[TEST 1] Creating entity with protocol names...")
    clean_entity = create_entity_state(
        entity_id='npc_001',
        position=(5.0, 0.0, 3.0),
        velocity=(1.0, 0.0, 0.0)
    )
    print(f"✓ Created: {clean_entity}")
    
    # TEST 2: Guardrail catches contamination
    print("\n[TEST 2] Testing guardrail against contaminated snapshot...")
    contaminated = {
        'id': 'npc_002',
        'pos': [1.0, 2.0, 3.0],  # FORBIDDEN!
        'position': [1.0, 2.0, 3.0]  # Both present - contaminated!
    }
    
    try:
        build_entity_slice_v1(contaminated)
        print("✗ FAILED - Guardrail didn't catch contamination!")
    except SliceError as e:
        print(f"✓ Guardrail triggered: {str(e)[:80]}...")
    
    # TEST 3: Kernel writeback with cleanup
    print("\n[TEST 3] Kernel writeback with mandatory cleanup...")
    
    snapshot = {'spatial3d': {'entities': {}}}
    
    # Simulate kernel accidentally writing both names
    kernel_output = {
        'spatial3d': {
            'entities': {
                'npc_003': {
                    'id': 'npc_003',
                    'pos': (10.0, 0.0, 5.0),  # Kernel name (will be purged)
                    'vel': (0.5, 0.0, 0.0),   # Kernel name (will be purged)
                }
            }
        }
    }
    
    write_kernel_output_to_snapshot(snapshot, kernel_output)
    
    entity = snapshot['spatial3d']['entities']['npc_003']
    print(f"   After writeback: {list(entity.keys())}")
    
    # Verify purity
    if 'position' in entity and 'pos' not in entity:
        print("   ✓ Snapshot pure - only protocol names present")
    else:
        print("   ✗ Contamination detected!")
    
    # TEST 4: Purity validation
    print("\n[TEST 4] Snapshot purity validation...")
    violations = validate_snapshot_purity(snapshot)
    
    if not violations:
        print("   ✓ Snapshot purity verified - no violations")
    else:
        print(f"   ✗ Violations found: {violations}")
    
    print("\n" + "="*70)
    print("SUMMARY: Snapshot Purity Enforcement")
    print("="*70)
    print("""
Three-layer defense:

1. GUARDRAIL (SliceBuilder)
   - Rejects snapshots with forbidden fields
   - Fails hard, fails fast

2. SOURCE INTEGRITY (create_entity_state)
   - Uses ONLY protocol names
   - Clean from birth

3. DEFENSIVE CLEANUP (write_kernel_output)
   - Translates kernel → protocol
   - Purges leaked keys after write

Result: Snapshot = Pure Wire Protocol
    """)
