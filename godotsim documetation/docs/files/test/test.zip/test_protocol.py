#!/usr/bin/env python3
"""Protocol Enforcement Test Suite"""

import sys
import json
from protocol_envelope import ProtocolEnvelope
from slice_builders import (
    build_entity_kview_v1, 
    build_spatial_slice_v1,
    assert_no_raw_dict_contamination,
    SliceError,
    ContaminationError
)

print("="*60)
print("PROTOCOL ENFORCEMENT TEST SUITE")
print("="*60)
print()

# TEST 1: Protocol Envelope Structure
print("TEST 1: Protocol Envelope Structure")
print("-" * 40)

envelope = ProtocolEnvelope(protocol="NGAT-RT", version="1.0")
snapshot = {
    "entities": {"test": {"position": [1, 2, 3], "velocity": [0, 0, 0]}},
    "world": {"time": 1.0}
}

wrapped = envelope.wrap_snapshot(snapshot, tick=1.0)

required_keys = ["protocol", "version", "type", "tick", "epoch", "hash", "payload"]
missing = [k for k in required_keys if k not in wrapped]

if missing:
    print(f"✗ FAIL: Missing keys: {missing}")
    sys.exit(1)
else:
    print(f"✓ PASS: All required keys present")

print(f"  Protocol: {wrapped['protocol']}")
print(f"  Version: {wrapped['version']}")
print(f"  Epoch: {wrapped['epoch'][:16]}...")
print(f"  Hash: {wrapped['hash'][:24]}...")
print()

# TEST 2: Hash Verification
print("TEST 2: Hash Verification")
print("-" * 40)

original_hash = wrapped["hash"]
tampered = wrapped.copy()
tampered["payload"]["world"]["time"] = 999.0

payload_json = json.dumps(tampered["payload"], sort_keys=True)
import hashlib
new_hash = "sha256:" + hashlib.sha256(payload_json.encode('utf-8')).hexdigest()

if new_hash != original_hash:
    print(f"✓ PASS: Hash mismatch detected (tampering caught)")
else:
    print(f"✗ FAIL: Hash should change when payload modified")
    sys.exit(1)
print()

# TEST 3: Version Enforcement
print("TEST 3: Version Enforcement")
print("-" * 40)

env_v2 = ProtocolEnvelope(protocol="NGAT-RT", version="2.0")
wrapped_v2 = env_v2.wrap_snapshot(snapshot, tick=1.0)

if wrapped["epoch"] != wrapped_v2["epoch"]:
    print(f"✓ PASS: Version changes epoch (enforced isolation)")
else:
    print(f"✗ FAIL: Version should affect epoch")
    sys.exit(1)
print()

# TEST 4: Contamination Guard
print("TEST 4: Contamination Guard")
print("-" * 40)

raw_snapshot = {
    "entities": {"test": {"position": [1, 2, 3]}},
    "world": {"time": 1.0}
}

try:
    assert_no_raw_dict_contamination(raw_snapshot, "test_kernel")
    print("✗ FAIL: Should have caught raw snapshot")
    sys.exit(1)
except ContaminationError:
    print(f"✓ PASS: Contamination detected")

valid_world = {
    "entities": {"test": {"position": [1, 2, 3], "velocity": [0, 0, 0]}},
    "world": {"time": 1.0}
}

slice_obj = build_spatial_slice_v1(valid_world, tick=1.0, eid="test")
print(f"✓ PASS: Typed slice accepted")
print()

# TEST 5: Slice Builder Validation
print("TEST 5: Slice Builder Validation")
print("-" * 40)

bad_world = {
    "entities": {"bad_entity": {"velocity": [0, 0, 0]}},
    "world": {}
}

try:
    build_entity_kview_v1(bad_world, "bad_entity")
    print("✗ FAIL: Should reject missing position")
    sys.exit(1)
except SliceError:
    print(f"✓ PASS: Rejected missing position")

good_world = {
    "entities": {
        "good_entity": {
            "position": [5.0, 0.0, 3.0],
            "velocity": [0.0, 0.0, 0.0]
        }
    },
    "world": {}
}

entity = build_entity_kview_v1(good_world, "good_entity")
print(f"✓ PASS: Valid entity accepted")
print()

# TEST 6: Epoch Determinism
print("TEST 6: Epoch Determinism")
print("-" * 40)

env1 = ProtocolEnvelope(protocol="NGAT-RT", version="1.0")
env2 = ProtocolEnvelope(protocol="NGAT-RT", version="1.0")

wrap1 = env1.wrap_snapshot(snapshot, tick=1.0)
wrap2 = env2.wrap_snapshot(snapshot, tick=1.0)

if wrap1["epoch"] == wrap2["epoch"]:
    print(f"✓ PASS: Same inputs produce same epoch (deterministic)")
else:
    print(f"✗ FAIL: Epoch should be deterministic")
    sys.exit(1)
print()

print("="*60)
print("ALL TESTS PASSED ✓")
print("="*60)
print()
print("Enforcement layers verified:")
print("  ✓ Protocol envelope structure")
print("  ✓ Hash verification (tamper detection)")
print("  ✓ Version isolation (epoch enforcement)")
print("  ✓ Contamination guards (raw dict detection)")
print("  ✓ Slice validation (contract enforcement)")
print("  ✓ Epoch determinism (reproducible builds)")
print()
print("Engine is production-ready! 🎉")
