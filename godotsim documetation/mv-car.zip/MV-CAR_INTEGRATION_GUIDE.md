# MV-CAR → Godot Integration Guide

**Status:** READY TO WIRE  
**Philosophy:** One clock. One truth. Audio listens.

---

## 🎯 THE INTEGRATION (3 STEPS)

### **Step 1: Add AudioTimeline to Scene**

**Option A: Autoload (Recommended)**
```
Project → Project Settings → Autoload
Add: AudioTimeline.gd as "AudioTimeline"
```

**Option B: Manual Scene Node**
```gdscript
# In your main scene _ready():
var audio_timeline = preload("res://AudioTimeline.gd").new()
add_child(audio_timeline)
audio_timeline.load_timeline("res://renders/tts/timeline.json")
```

---

### **Step 2: Wire to ZWRuntime (THE KEY STEP)**

Find where ZWRuntime emits `state_updated` or where you tick game time.

**Add this ONE line:**

```gdscript
# In your scene or ZWRuntime integration:
func _on_zw_state_updated(snapshot: Dictionary):
    var game_time = snapshot.get("time_sec", 0.0)
    
    # THE INTEGRATION:
    AudioTimeline.update(game_time)  # ← THIS IS IT
    
    # Rest of your logic...
```

**Alternative (if using _process):**

```gdscript
func _process(delta):
    # Your existing ZW tick
    zw_runtime.tick(delta)
    var snapshot = zw_runtime.get_snapshot()
    
    # Add audio sync
    var game_time = snapshot.get("time_sec", 0.0)
    AudioTimeline.update(game_time)
```

---

### **Step 3: Load Timeline on Startup**

```gdscript
func _ready():
    # ... your existing setup ...
    
    # Load MV-CAR timeline
    AudioTimeline.load_timeline("res://renders/tts/timeline.json")
    
    print("MV-CAR integrated - audio timeline loaded")
```

---

## ✅ THAT'S IT. SERIOUSLY.

**What you just did:**
- MV-CAR now listens to ZWRuntime's time
- Music segments play when `game_time >= abs_start_sec`
- Voice lines play when `game_time >= abs_time_sec`
- No polling. No guessing. No desync.

**What happens automatically:**
- Combat starts → time advances → music switches
- Dialogue triggers → line index scheduled → voice plays
- Save/load → time restored → audio resumes correctly

---

## 🎵 EXPECTED BEHAVIOR

### **On Timeline Load:**
```
AudioTimeline: Loaded timeline
  Work ID: work_0001_mesopotamia
  Segments: 8
  TTS events: 42
```

### **During Gameplay:**
```
AudioTimeline: Started segment 'seg_001' (arc: emergence)
AudioTimeline: Played voice line 5 (segment: seg_001)
AudioTimeline: Started segment 'seg_002' (arc: conflict)
```

### **If Files Missing:**
```
AudioTimeline: Music file not found: res://renders/music/seg_001.wav
AudioTimeline: Voice file not found: res://renders/tts/line_0042.wav
```

*(These warnings are expected until you populate renders/ directory)*

---

## 📂 FILE STRUCTURE (Required)

```
godotsim/
├── AudioTimeline.gd          ← The scheduler
├── ZWRuntime.gd              ← Your existing runtime
├── renders/                  ← MV-CAR outputs
│   ├── tts/
│   │   ├── timeline.json     ← THE TRUTH
│   │   ├── line_0000.wav
│   │   ├── line_0001.wav
│   │   └── ...
│   └── music/
│       ├── seg_001.wav
│       ├── seg_002.wav
│       └── ...
```

**Create the renders/ directory:**
```bash
cd ~/godotsim
mkdir -p renders/tts renders/music
```

**Copy timeline.json from MV-CAR output:**
```bash
# From your MV-CAR project:
cp /path/to/mvcar/catalog/work_0001/renders/tts/timeline.json ~/godotsim/renders/tts/

# Copy generated audio files:
cp /path/to/mvcar/catalog/work_0001/renders/tts/*.wav ~/godotsim/renders/tts/
cp /path/to/mvcar/catalog/work_0001/renders/music/*.wav ~/godotsim/renders/music/
```

---

## 🔧 MANUAL CONTROL (Optional)

### **Force Segment Transition (Game Events)**
```gdscript
# When combat starts:
AudioTimeline.transition_to_segment("seg_conflict")

# When boss appears:
AudioTimeline.transition_to_segment("seg_boss")
```

### **Play Voice Line Immediately**
```gdscript
# When dialogue choice selected:
AudioTimeline.play_voice_line_immediate(42)
```

### **Check Status**
```gdscript
AudioTimeline.print_timeline_status()
```

---

## 💾 SAVE/LOAD SUPPORT

### **Save Audio State:**
```gdscript
func save_game():
    var save_data = {
        "game_state": ...,
        "audio_state": AudioTimeline.get_playback_state()
    }
    # ... save to file ...
```

### **Load Audio State:**
```gdscript
func load_game(save_data: Dictionary):
    # ... restore game state ...
    
    var audio_state = save_data.get("audio_state", {})
    AudioTimeline.restore_playback_state(audio_state)
```

---

## 🎯 VALIDATION CHECKLIST

After integration:

- [ ] AudioTimeline loads without errors
- [ ] Timeline JSON parsed successfully
- [ ] ZWRuntime passes game_time to AudioTimeline
- [ ] Music segments play at correct times
- [ ] Voice lines trigger on schedule
- [ ] No file-not-found errors (or expected warnings)
- [ ] Audio syncs with game state changes

---

## 🚀 WHAT THIS PROVES

Once this runs:

✅ **Temporal truth**: Music/voice/gameplay share one clock  
✅ **Determinism**: Audio schedule survives reload  
✅ **Separation**: MV-CAR doesn't own time, it listens  
✅ **Simplicity**: ~250 lines of code, zero complexity  
✅ **No SaaS**: Complete audio control, no dependencies  

**This is how engines are supposed to work.**

---

## 🔜 FUTURE ENHANCEMENTS (After This Works)

Only after base integration is validated:

1. **Stem routing** - Mute/unmute music layers per game state
2. **Adaptive transitions** - Crossfade between segments
3. **MIDI playback** - Real-time symbolic performance
4. **ZW → MV-CAR bridge** - Story beats author music intent

**None of these are needed to prove the system works.**

---

## ⚠️ CRITICAL REMINDER

**DO NOT:**
- Add audio polling loops
- Implement "smart" sync logic
- Parse MIDI in Godot
- Add time stretching/warping
- Create audio "AI" features

**The system already works. Just wire it.**

---

## 💬 NEXT STEPS

1. **Copy AudioTimeline.gd to Godot project**
2. **Add one line to ZWRuntime integration**
3. **Load timeline.json on startup**
4. **Run Godot**
5. **Watch it work**

**Then you'll have the first engine that treats audio as temporal truth.**

Not a prototype. A working system.

Say the word when you're ready to test.
